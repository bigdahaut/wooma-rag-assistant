# from hardware_lock import verify_license, LicenseError
import sys
# try:
#     verify_license()
# except LicenseError as e:
#     print(f"\n{'='*50}")
#     print(f"  LICENSE ERROR")
#     print(f"{'='*50}")
#     print(f"  {e}")
#     print(f"{'='*50}\n")
#     sys.exit(1)
import os
from pathlib import Path
from typing import List, Tuple, Dict, Any
import logging
from datetime import datetime
import time
import threading
import queue
from tkinter import filedialog
import re

import ttkbootstrap as ttk
from ttkbootstrap.constants import *
from ttkbootstrap.dialogs import Messagebox

# Third-party imports
import chromadb
from chromadb.config import Settings

# Document processing imports
import docx
import pymupdf4llm  # Instead of  pypdf
import openpyxl
import csv
import json
import pandas as pd

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('vectorization.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

class DocumentProcessor:
    """Handles processing of various document formats."""
    SUPPORTED_EXTENSIONS = {'.txt', '.docx', '.pdf', '.xlsx', '.csv', '.json'}

    @staticmethod
    def sanitize_filename(filename: str) -> str:
        """Sanitize filename by replacing problematic characters with underscores."""
        name, ext = os.path.splitext(filename)
        sanitized_name = re.sub(r'[^a-zA-Z0-9\-_.]', '_', name)
        sanitized_name = re.sub(r'_+', '_', sanitized_name)
        sanitized_name = sanitized_name.strip('_')
        return f"{sanitized_name}{ext}"

    @staticmethod
    def read_txt(file_path: Path) -> List[str]:
        try:
            with open(file_path, 'r', encoding='utf-8', errors='replace') as f:
                return [line.strip() for line in f if line.strip()]
        except Exception as e:
            logger.error(f"Error reading {file_path}: {e}")
            return []

    @staticmethod
    def read_docx(file_path: Path) -> List[str]:
        try:
            doc = docx.Document(file_path)
            content = [p.text.strip() for p in doc.paragraphs if p.text.strip()]
            for table in doc.tables:
                for row in table.rows:
                    row_text = " | ".join(cell.text.strip() for cell in row.cells)
                    if row_text:
                        content.append(row_text)
            return content
        except Exception as e:
            logger.error(f"Error reading {file_path}: {e}")
            return []

    @staticmethod
    def read_pdf(file_path: Path) -> List[str]:
        try:
            md_text = pymupdf4llm.to_markdown(str(file_path))
            
            if not md_text or not md_text.strip():
                return []

            CHUNK_SIZE = 1000      
            CHUNK_OVERLAP = 100    

            chunks = []
            paragraphs = [p.strip() for p in md_text.split('\n\n') if p.strip()]
            
            current_chunk = ""
            for para in paragraphs:
                if len(current_chunk) + len(para) > CHUNK_SIZE and len(current_chunk) > 0:
                    chunks.append(current_chunk.strip())
                    current_chunk = current_chunk[-CHUNK_OVERLAP:] if len(current_chunk) > CHUNK_OVERLAP else ""
                
                current_chunk += para + "\n\n"
            
            if current_chunk.strip():
                chunks.append(current_chunk.strip())

            final_chunks = []
            for c in chunks:
                if len(c) > CHUNK_SIZE:
                    for i in range(0, len(c), CHUNK_SIZE - CHUNK_OVERLAP):
                        final_chunks.append(c[i : i + CHUNK_SIZE])
                else:
                    final_chunks.append(c)

            return final_chunks

        except Exception as e:
            logger.error(f"Error reading PDF {file_path}: {e}")
            return []

    @staticmethod
    def read_xlsx(file_path: Path) -> List[str]:
        try:
            all_sheets = pd.read_excel(file_path, sheet_name=None)
            final_content = []
            
            CHUNK_SIZE = 1200
            CHUNK_OVERLAP = 150

            for sheet_name, df in all_sheets.items():
                md_table = df.to_markdown(index=False)
                
                if not md_table:
                    continue

                header_prefix = f"### Sheet: {sheet_name}\n\n"
                
                if len(md_table) < CHUNK_SIZE:
                    final_content.append(header_prefix + md_table)
                else:
                    for i in range(0, len(md_table), CHUNK_SIZE - CHUNK_OVERLAP):
                        chunk = md_table[i : i + CHUNK_SIZE]
                        final_content.append(f"{header_prefix}(Continued...)\n\n{chunk}")
                        
            return final_content
            
        except Exception as e:
            logger.error(f"Error reading XLSX {file_path} with Pandas: {e}")
            return []

    @staticmethod
    def read_csv(file_path: Path) -> List[str]:
        try:
            with open(file_path, 'r', encoding='utf-8-sig', errors='replace') as f:
                sniffer = csv.Sniffer()
                dialect = sniffer.sniff(f.read(1024))
                f.seek(0)
                reader = csv.DictReader(f, dialect=dialect)
                return [" | ".join(f"{k}: {v}" for k, v in row.items() if v) for row in reader]
        except Exception as e:
            logger.error(f"Error reading {file_path}: {e}")
            return []

    @staticmethod
    def read_json(file_path: Path) -> List[str]:
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            if isinstance(data, list):
                return [json.dumps(item) for item in data]
            elif isinstance(data, dict):
                return [json.dumps(data)]
            return []
        except Exception as e:
            logger.error(f"Error reading {file_path}: {e}")
            return []

    def process_file(self, file_path: Path) -> Tuple[List[str], List[Dict[str, Any]]]:
        extension = file_path.suffix.lower()
        if extension not in self.SUPPORTED_EXTENSIONS:
            return [], []
        
        read_methods = {
            '.txt': self.read_txt, '.docx': self.read_docx, '.pdf': self.read_pdf,
            '.xlsx': self.read_xlsx, '.csv': self.read_csv, '.json': self.read_json
        }
        lines = read_methods[extension](file_path)
        
        if not lines:
            return [], []

        file_stat = file_path.stat()
        sanitized_name = self.sanitize_filename(file_path.name)
        metadata_base = {
            "filename": sanitized_name,
            "original_filename": file_path.name,
            "file_path": str(file_path),
            "file_type": extension,
            "file_size": file_stat.st_size,
            "processed_at": datetime.now().isoformat()
        }
        
        metadatas = [{**metadata_base, "line_number": i + 1} for i, _ in enumerate(lines)]
        return lines, metadatas

class CollectionManager:
    """Manages ChromaDB collections."""
    
    def __init__(self):
        self.client = chromadb.PersistentClient(
            path="chroma_storage", 
            settings=Settings(anonymized_telemetry=False)
        )
    
    @staticmethod
    def sanitize_collection_name(name: str) -> str:
        """Sanitize collection name by replacing invalid characters with underscores."""
        name = name.strip()
        name = name.replace(' ', '_')
        sanitized = re.sub(r'[^a-zA-Z0-9\-_]', '_', name)
        sanitized = re.sub(r'_+', '_', sanitized)
        sanitized = sanitized.strip('_')
        
        if not sanitized:
            sanitized = "collection"
        
        return sanitized
    
    @staticmethod
    def validate_collection_name(name: str) -> Tuple[bool, str]:
        """Validate collection name. Returns (is_valid, error_message)"""
        if not name or not name.strip():
            return False, "Collection name cannot be empty."
        
        invalid_chars = re.findall(r'[^a-zA-Z0-9\-_]', name)
        if invalid_chars:
            unique_invalid = list(set(invalid_chars))
            chars_str = ', '.join([f"'{c}'" for c in unique_invalid if c != ' '])
            if ' ' in unique_invalid:
                chars_str = f"spaces, {chars_str}" if chars_str else "spaces"
            return False, f"Collection name contains invalid characters: {chars_str}. Only letters, numbers, hyphens, and underscores are allowed."
        
        if len(name) > 63:
            return False, f"Collection name is too long. Maximum length is 63 characters. Current length: {len(name)}"
        
        if len(name) < 3:
            return False, f"Collection name is too short. Minimum length is 3 characters. Current length: {len(name)}"
        
        return True, ""
    
    def list_collections(self) -> List[str]:
        """Return list of all collection names."""
        try:
            collections = self.client.list_collections()
            return [col.name for col in collections]
        except Exception as e:
            logger.error(f"Failed to list collections: {e}")
            return []
    
    def get_collection_info(self, collection_name: str) -> Dict[str, Any]:
        """Get information about a specific collection."""
        try:
            collection = self.client.get_collection(name=collection_name)
            count = collection.count()
            return {
                "name": collection_name,
                "count": count,
                "exists": True
            }
        except Exception as e:
            logger.error(f"Failed to get info for collection {collection_name}: {e}")
            return {"name": collection_name, "count": 0, "exists": False}
    
    def collection_exists(self, collection_name: str) -> bool:
        """Check if a collection exists."""
        try:
            self.client.get_collection(name=collection_name)
            return True
        except:
            return False
    
    def rename_collection(self, old_name: str, new_name: str) -> Tuple[bool, str]:
        """Rename a collection. Returns (success, message)"""
        try:
            is_valid, error_msg = self.validate_collection_name(new_name)
            if not is_valid:
                return False, error_msg
            
            sanitized_name = self.sanitize_collection_name(new_name)
            
            if self.collection_exists(sanitized_name):
                return False, f"Collection '{sanitized_name}' already exists."
            
            if sanitized_name == old_name:
                return True, "Collection name unchanged."
            
            old_collection = self.client.get_collection(name=old_name)
            all_data = old_collection.get()
            
            if not all_data['ids']:
                self.client.create_collection(name=sanitized_name)
                self.client.delete_collection(name=old_name)
                return True, f"Collection renamed from '{old_name}' to '{sanitized_name}'."
            
            new_collection = self.client.create_collection(name=sanitized_name)
            
            batch_size = 100
            for i in range(0, len(all_data['ids']), batch_size):
                batch_ids = all_data['ids'][i:i+batch_size]
                batch_documents = all_data['documents'][i:i+batch_size] if all_data['documents'] else None
                batch_metadatas = all_data['metadatas'][i:i+batch_size] if all_data['metadatas'] else None
                
                new_collection.add(
                    ids=batch_ids,
                    documents=batch_documents,
                    metadatas=batch_metadatas
                )
            
            self.client.delete_collection(name=old_name)
            
            logger.info(f"Successfully renamed collection from '{old_name}' to '{sanitized_name}'")
            return True, f"Collection renamed from '{old_name}' to '{sanitized_name}'."
            
        except Exception as e:
            error_msg = f"Failed to rename collection: {str(e)}"
            logger.error(error_msg)
            return False, error_msg
    
    def delete_collection(self, collection_name: str) -> Tuple[bool, str]:
        """Delete a collection. Returns (success, message)."""
        try:
            self.client.delete_collection(name=collection_name)
            logger.info(f"Successfully deleted collection: {collection_name}")
            return True, f"Collection '{collection_name}' deleted successfully."
        except Exception as e:
            error_msg = f"Failed to delete collection: {str(e)}"
            logger.error(error_msg)
            return False, error_msg

class DataVectorizerApp(ttk.Window):
    def __init__(self):
        super().__init__(themename="litera")
        self.title("RAG Document Vectorizer")
        self.geometry("1000x800")
        
        self.gui_queue = queue.Queue()
        self.after(100, self.process_gui_queue)
        
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill=BOTH, expand=YES, padx=10, pady=10)
        
        self.vectorize_tab = ttk.Frame(self.notebook)
        self.collections_tab = ttk.Frame(self.notebook)
        
        self.notebook.add(self.vectorize_tab, text="Vectorize Documents")
        self.notebook.add(self.collections_tab, text="Manage Collections")
        
        self.create_vectorize_tab()
        self.create_collections_tab()
        
        self.status_bar = ttk.Label(self, text="Ready", relief="sunken", anchor="w")
        self.status_bar.pack(side=BOTTOM, fill=X, padx=10, pady=(0, 10))
        
        self.collection_manager = CollectionManager()
        self.notebook.bind("<<NotebookTabChanged>>", self.on_tab_changed)
        self.collection_name.trace_add("write", self.validate_collection_name_input)

    def process_gui_queue(self):
        try:
            while True:
                task = self.gui_queue.get_nowait()
                task()
        except queue.Empty:
            pass
        self.after(100, self.process_gui_queue)
    
    def on_tab_changed(self, event):
        if self.notebook.index(self.notebook.select()) == 1:
            self.refresh_collections_list()

    def validate_collection_name_input(self, *args):
        name = self.collection_name.get().strip()
        if name and name != "Enter a unique name for the collection":
            is_valid, error_msg = CollectionManager.validate_collection_name(name)
            if not is_valid:
                if hasattr(self, 'validation_label'):
                    self.validation_label.config(text=error_msg, foreground="red")
            else:
                if hasattr(self, 'validation_label'):
                    self.validation_label.config(text="Valid collection name", foreground="green")
        else:
            if hasattr(self, 'validation_label'):
                self.validation_label.config(text="")

    def validate_and_sanitize_collection_name(self, name: str, show_warning: bool = True) -> Tuple[bool, str]:
        is_valid, error_msg = CollectionManager.validate_collection_name(name)
        if not is_valid:
            if show_warning:
                Messagebox.show_warning(error_msg, "Invalid Collection Name")
            return False, error_msg
        
        sanitized = CollectionManager.sanitize_collection_name(name)
        if sanitized != name and show_warning:
            Messagebox.show_info(
                f"Collection name has been sanitized to follow naming rules:\n\n"
                f"Original: '{name}'\n"
                f"Sanitized: '{sanitized}'",
                "Name Sanitized"
            )
        return True, sanitized

    def create_vectorize_tab(self):
        parent = self.vectorize_tab
        parent.grid_columnconfigure(0, weight=1)
        parent.grid_rowconfigure(1, weight=1)
        
        config_frame = ttk.LabelFrame(parent, text="Configuration")
        config_frame.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        config_frame.grid_columnconfigure(1, weight=1)
        
        config_inner = ttk.Frame(config_frame, padding=15)
        config_inner.pack(fill="both", expand=True)
        
        ttk.Label(config_inner, text="Data Folder:", width=15, anchor="e").grid(row=0, column=0, padx=5, pady=8, sticky='w')
        self.folder_path = ttk.StringVar()
        folder_entry = ttk.Entry(config_inner, textvariable=self.folder_path, width=60)
        folder_entry.grid(row=0, column=1, sticky="ew", padx=5, pady=8)
        self.select_folder_button = ttk.Button(config_inner, text="Browse...", command=self.select_folder, bootstyle="outline-info", width=12)
        self.select_folder_button.grid(row=0, column=2, padx=5, pady=8)

        ttk.Label(config_inner, text="Collection Name:", width=15, anchor="e").grid(row=1, column=0, padx=5, pady=8, sticky='w')
        self.collection_name = ttk.StringVar()
        collection_entry = ttk.Entry(config_inner, textvariable=self.collection_name, width=60, font=("TkDefaultFont", 10))
        collection_entry.grid(row=1, column=1, columnspan=2, sticky="ew", padx=5, pady=8)
        collection_entry.insert(0, "Enter a unique name for the collection")
        collection_entry.bind("<FocusIn>", lambda e: e.widget.delete(0, "end") if e.widget.get() == "Enter a unique name for the collection" else None)
        collection_entry.bind("<FocusOut>", lambda e: e.widget.insert(0, "Enter a unique name for the collection") if not e.widget.get() else None)
        
        info_label = ttk.Label(config_inner, text="Naming rules: letters (a-z), numbers (0-9), hyphens (-), underscores (_) | Length: 3-63 characters",
                               foreground="gray", font=("TkDefaultFont", 8))
        info_label.grid(row=2, column=1, sticky="w", padx=5, pady=(0, 5))

        file_frame = ttk.LabelFrame(parent, text="Documents")
        file_frame.grid(row=1, column=0, sticky="nsew", pady=10)
        file_frame.grid_columnconfigure(0, weight=1)
        file_frame.grid_rowconfigure(0, weight=1)
        
        file_inner = ttk.Frame(file_frame, padding=15)
        file_inner.pack(fill="both", expand=True)
        file_inner.grid_columnconfigure(0, weight=1)
        file_inner.grid_rowconfigure(0, weight=1)
        
        tree_frame = ttk.Frame(file_inner)
        tree_frame.grid(row=0, column=0, sticky="nsew")
        tree_frame.grid_columnconfigure(0, weight=1)
        tree_frame.grid_rowconfigure(0, weight=1)
        
        scrollbar_y = ttk.Scrollbar(tree_frame)
        scrollbar_y.grid(row=0, column=1, sticky="ns")
        scrollbar_x = ttk.Scrollbar(tree_frame, orient="horizontal")
        scrollbar_x.grid(row=1, column=0, sticky="ew")
        
        self.file_list = ttk.Treeview(tree_frame, columns=("filename", "size", "modified"), show="headings",
                                      yscrollcommand=scrollbar_y.set, xscrollcommand=scrollbar_x.set)
        self.file_list.heading("filename", text="File Name")
        self.file_list.heading("size", text="Size (KB)")
        self.file_list.heading("modified", text="Modified Date")
        self.file_list.column("filename", width=550)
        self.file_list.column("size", width=100, anchor='center')
        self.file_list.column("modified", width=150, anchor='center')
        self.file_list.grid(row=0, column=0, sticky="nsew")
        
        scrollbar_y.config(command=self.file_list.yview)
        scrollbar_x.config(command=self.file_list.xview)
        
        self.folder_size_label = ttk.Label(file_inner, text="Total Folder Size: 0.00 KB", anchor='e')
        self.folder_size_label.grid(row=1, column=0, sticky="ew", pady=(5,0))

        action_frame = ttk.LabelFrame(parent, text="Actions")
        action_frame.grid(row=2, column=0, sticky="ew", pady=(10, 0))
        action_frame.grid_columnconfigure((0, 1), weight=1)
        
        action_inner = ttk.Frame(action_frame, padding=15)
        action_inner.pack(fill="both", expand=True)
        action_inner.grid_columnconfigure((0, 1), weight=1)
        
        self.upload_button = ttk.Button(action_inner, text="Upload Files to Folder", command=self.upload_files, bootstyle="success", state="disabled")
        self.upload_button.grid(row=0, column=0, padx=5, pady=5, sticky="ew")
        self.vectorize_button = ttk.Button(action_inner, text="Vectorize All Files", command=self.start_vectorization, bootstyle="primary", state="disabled")
        self.vectorize_button.grid(row=0, column=1, padx=5, pady=5, sticky="ew")
        
        self.progress = ttk.Progressbar(action_inner, mode='determinate', bootstyle="striped")
        self.progress.grid(row=1, column=0, columnspan=2, sticky="ew", padx=5, pady=(10, 5))
        
        self.status_label = ttk.Label(action_inner, text="Ready. Please provide a data folder and collection name.")
        self.status_label.grid(row=2, column=0, columnspan=2, sticky="w", padx=5, pady=5)
        
        self.folder_path.trace_add("write", self._validate_inputs)
        self.collection_name.trace_add("write", self._validate_inputs)
    
    def create_collections_tab(self):
        parent = self.collections_tab
        parent.grid_columnconfigure(0, weight=1)
        parent.grid_rowconfigure(1, weight=1)
        
        control_frame = ttk.Frame(parent)
        control_frame.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        control_frame.grid_columnconfigure(0, weight=1)
        
        ttk.Label(control_frame, text="Collection Management", font=("TkDefaultFont", 10, "bold")).grid(row=0, column=0, sticky="w", padx=5)
        
        refresh_btn = ttk.Button(control_frame, text="Refresh List", command=self.refresh_collections_list, bootstyle="info-outline", width=15)
        refresh_btn.grid(row=0, column=1, padx=5)
        
        rules_label = ttk.Label(control_frame, 
                                text="Naming rules: letters (a-z), numbers (0-9), hyphens (-), underscores (_) | Length: 3-63 characters",
                                foreground="gray", font=("TkDefaultFont", 8))
        rules_label.grid(row=1, column=0, columnspan=2, sticky="w", padx=5, pady=(5, 0))
        
        list_frame = ttk.LabelFrame(parent, text="Existing Collections")
        list_frame.grid(row=1, column=0, sticky="nsew", pady=10)
        list_frame.grid_columnconfigure(0, weight=1)
        list_frame.grid_rowconfigure(0, weight=1)
        
        list_inner = ttk.Frame(list_frame, padding=10)
        list_inner.pack(fill="both", expand=True)
        list_inner.grid_columnconfigure(0, weight=1)
        list_inner.grid_rowconfigure(0, weight=1)
        
        tree_frame = ttk.Frame(list_inner)
        tree_frame.grid(row=0, column=0, sticky="nsew")
        tree_frame.grid_columnconfigure(0, weight=1)
        tree_frame.grid_rowconfigure(0, weight=1)
        
        scrollbar = ttk.Scrollbar(tree_frame)
        scrollbar.grid(row=0, column=1, sticky="ns")
        
        self.collections_list = ttk.Treeview(tree_frame, columns=("name", "count", "status"), 
                                             show="headings", yscrollcommand=scrollbar.set)
        self.collections_list.heading("name", text="Collection Name")
        self.collections_list.heading("count", text="Document Chunks")
        self.collections_list.heading("status", text="Status")
        self.collections_list.column("name", width=450)
        self.collections_list.column("count", width=150, anchor='center')
        self.collections_list.column("status", width=100, anchor='center')
        self.collections_list.grid(row=0, column=0, sticky="nsew")
        
        scrollbar.config(command=self.collections_list.yview)
        self.collections_list.bind('<<TreeviewSelect>>', self.on_collection_select)
        
        details_frame = ttk.LabelFrame(parent, text="Collection Actions")
        details_frame.grid(row=2, column=0, sticky="ew", pady=10)
        details_frame.grid_columnconfigure((0, 1), weight=1)
        
        details_inner = ttk.Frame(details_frame, padding=15)
        details_inner.pack(fill="both", expand=True)
        details_inner.grid_columnconfigure((0, 1), weight=1)
        
        info_frame = ttk.Frame(details_inner)
        info_frame.grid(row=0, column=0, columnspan=2, sticky="ew", pady=5)
        info_frame.grid_columnconfigure((0, 1, 2, 3), weight=0)
        info_frame.grid_columnconfigure(4, weight=1)
        
        ttk.Label(info_frame, text="Selected:", font=("TkDefaultFont", 9, "bold")).grid(row=0, column=0, padx=5, sticky="w")
        self.selected_collection_var = ttk.StringVar(value="None")
        selected_label = ttk.Label(info_frame, textvariable=self.selected_collection_var, foreground="blue", font=("TkDefaultFont", 9, "bold"))
        selected_label.grid(row=0, column=1, padx=5, sticky="w")
        
        ttk.Label(info_frame, text="Chunks:", font=("TkDefaultFont", 9, "bold")).grid(row=0, column=2, padx=(20, 5), sticky="w")
        self.selected_count_var = ttk.StringVar(value="0")
        ttk.Label(info_frame, textvariable=self.selected_count_var, font=("TkDefaultFont", 9)).grid(row=0, column=3, padx=5, sticky="w")
        
        button_frame = ttk.Frame(details_inner)
        button_frame.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(10, 0))
        button_frame.grid_columnconfigure(0, weight=1)
        button_frame.grid_columnconfigure(1, weight=1)
        
        self.rename_collection_button = ttk.Button(button_frame, text="Rename Collection", 
                                                   command=self.rename_selected_collection,
                                                   bootstyle="info", state="disabled", width=20)
        self.rename_collection_button.grid(row=0, column=0, padx=5, pady=5, sticky="ew")
        
        self.delete_collection_button = ttk.Button(button_frame, text="Delete Selected Collection", 
                                                   command=self.delete_selected_collection,
                                                   bootstyle="danger", state="disabled", width=20)
        self.delete_collection_button.grid(row=0, column=1, padx=5, pady=5, sticky="ew")
        
        warning_label = ttk.Label(details_inner, 
                                  text="Note: Collection names must contain only letters, numbers, hyphens, and underscores (no spaces or special characters)",
                                  foreground="darkorange")
        warning_label.grid(row=2, column=0, columnspan=2, sticky="w", pady=(10, 0), padx=5)
        
        stats_frame = ttk.LabelFrame(parent, text="Storage Statistics")
        stats_frame.grid(row=3, column=0, sticky="ew", pady=10)
        
        stats_inner = ttk.Frame(stats_frame, padding=10)
        stats_inner.pack(fill="both", expand=True)
        stats_inner.grid_columnconfigure((0, 1, 2, 3), weight=0)
        stats_inner.grid_columnconfigure(4, weight=1)
        
        ttk.Label(stats_inner, text="Total Collections:", font=("TkDefaultFont", 9)).grid(row=0, column=0, padx=5, sticky="w")
        self.total_collections_var = ttk.StringVar(value="0")
        ttk.Label(stats_inner, textvariable=self.total_collections_var, font=("TkDefaultFont", 9, "bold")).grid(row=0, column=1, padx=5, sticky="w")
        
        ttk.Label(stats_inner, text="Total Document Chunks:", font=("TkDefaultFont", 9)).grid(row=0, column=2, padx=(20, 5), sticky="w")
        self.total_chunks_var = ttk.StringVar(value="0")
        ttk.Label(stats_inner, textvariable=self.total_chunks_var, font=("TkDefaultFont", 9, "bold")).grid(row=0, column=3, padx=5, sticky="w")
        
        self.refresh_collections_list()

    def _validate_inputs(self, *args):
        folder = self.folder_path.get().strip()
        collection = self.collection_name.get().strip()
        is_collection_valid = collection and collection != "Enter a unique name for the collection"
        
        if is_collection_valid:
            is_valid, _ = CollectionManager.validate_collection_name(collection)
            if not is_valid:
                self.upload_button.config(state="disabled")
                self.vectorize_button.config(state="disabled")
                return
        
        are_all_fields_valid = folder and is_collection_valid
        new_state = "normal" if are_all_fields_valid else "disabled"
        self.upload_button.config(state=new_state)
        self.vectorize_button.config(state=new_state)

    def reset_ui(self):
        self.folder_path.set("")
        self.collection_name.set("")
        for i in self.file_list.get_children():
            self.file_list.delete(i)
        self.folder_size_label.config(text="Total Folder Size: 0.00 KB")
        self.status_label.config(text="Ready. Please provide a data folder and collection name.")
        self.progress.config(value=0)
        logger.info("UI has been reset for the next operation.")
        
    def set_ui_state(self, is_enabled):
        self.select_folder_button.config(state="normal" if is_enabled else "disabled")
        if is_enabled:
            self._validate_inputs()
        else:
            self.upload_button.config(state="disabled")
            self.vectorize_button.config(state="disabled")

    def select_folder(self):
        path = filedialog.askdirectory(title="Select a folder for your documents")
        if path:
            self.folder_path.set(path)
            self.update_file_list()

    def update_file_list(self):
        for i in self.file_list.get_children():
            self.file_list.delete(i)
        folder = self.folder_path.get()
        if not (folder and os.path.isdir(folder)):
            self.folder_size_label.config(text="Total Folder Size: 0.00 KB")
            return
        total_size = 0
        try:
            for item in sorted(os.scandir(folder), key=lambda e: e.name):
                if item.is_file():
                    size = item.stat().st_size
                    total_size += size
                    mod_time = datetime.fromtimestamp(item.stat().st_mtime).strftime("%Y-%m-%d %H:%M:%S")
                    self.file_list.insert("", "end", values=(item.name, f"{size / 1024:.2f}", mod_time))
        except OSError as e:
            self.status_label.config(text=f"Error reading folder: {e}")
        self.folder_size_label.config(text=f"Total Folder Size: {total_size / 1024:.2f} KB")

    def upload_files(self):
        folder = self.folder_path.get().strip()
        if not folder:
            Messagebox.show_warning("Please select or enter a destination folder first.", "Folder Not Selected")
            return
        if not os.path.exists(folder):
            if Messagebox.okcancel(f"The folder '{folder}' does not exist. Do you want to create it?", "Create Folder?"):
                try:
                    os.makedirs(folder)
                except OSError as e:
                    Messagebox.show_error(f"Failed to create folder: {e}", "Error")
                    return
            else:
                return
        files = filedialog.askopenfilenames(title="Select files to upload")
        if files:
            threading.Thread(target=self._upload_worker, args=(files, folder), daemon=True).start()

    def _upload_worker(self, files, folder):
        self.gui_queue.put(lambda: self.set_ui_state(False))
        start_time = time.time()
        self.gui_queue.put(lambda: self.progress.config(maximum=len(files)))
        for i, file_path in enumerate(files):
            try:
                filename = os.path.basename(file_path)
                dest_path = os.path.join(folder, filename)
                with open(file_path, 'rb') as fsrc, open(dest_path, 'wb') as fdest:
                    fdest.write(fsrc.read())
                elapsed = time.time() - start_time
                status_text = f"Uploaded {i+1}/{len(files)}: {filename} | Time: {elapsed:.2f}s"
                self.gui_queue.put(lambda i=i: self.progress.config(value=i + 1))
                self.gui_queue.put(lambda text=status_text: self.status_label.config(text=text))
            except Exception as e:
                logger.error(f"Failed to upload {file_path}: {e}")
                self.gui_queue.put(lambda f=filename: self.status_label.config(text=f"Error uploading {f}"))
        self.gui_queue.put(lambda: self.progress.config(value=0))
        self.gui_queue.put(lambda: self.status_label.config(text="Upload complete."))
        self.gui_queue.put(self.update_file_list)
        self.gui_queue.put(lambda: self.set_ui_state(True))

    def start_vectorization(self):
        folder = self.folder_path.get().strip()
        collection = self.collection_name.get().strip()
        
        if not (folder and os.path.isdir(folder)):
            Messagebox.show_warning("Please select a valid data folder.", "Invalid Folder")
            return
        
        if not collection or collection == "Enter a unique name for the collection":
            Messagebox.show_warning("Please enter a collection name.", "Invalid Collection Name")
            return
        
        is_valid, result = self.validate_and_sanitize_collection_name(collection, show_warning=True)
        if not is_valid:
            return
        
        sanitized_name = result
        self.collection_name.set(sanitized_name)
        
        threading.Thread(target=self._vectorize_worker, args=(folder, sanitized_name), daemon=True).start()

    def _vectorize_worker(self, documents_directory, collection_name):
        self.gui_queue.put(lambda: self.set_ui_state(False))
        start_time = time.time()
        try:
            processor = DocumentProcessor()
            docs_path = Path(documents_directory)
            supported_files = [fp for fp in docs_path.iterdir() if fp.is_file() and fp.suffix.lower() in processor.SUPPORTED_EXTENSIONS]
            if not supported_files:
                self.gui_queue.put(lambda: self.status_label.config(text="No supported documents found."))
                self.gui_queue.put(lambda: self.set_ui_state(True))
                return
            self.gui_queue.put(lambda: self.status_label.config(text="Initializing vector database..."))
            
            client = chromadb.PersistentClient(path="chroma_storage", settings=Settings(anonymized_telemetry=False))
            
            collection = client.get_or_create_collection(name=collection_name)
            self.gui_queue.put(lambda: self.progress.config(maximum=len(supported_files)))
            all_documents, all_metadatas = [], []
            for i, file_path in enumerate(supported_files):
                status_text = f"Processing file {i+1}/{len(supported_files)}: {file_path.name}..."
                self.gui_queue.put(lambda text=status_text: self.status_label.config(text=text))
                docs, metas = processor.process_file(file_path)
                all_documents.extend(docs)
                all_metadatas.extend(metas)
                self.gui_queue.put(lambda i=i: self.progress.config(value=i + 1))
            if not all_documents:
                self.gui_queue.put(lambda: self.status_label.config(text="No processable content found."))
                self.gui_queue.put(lambda: self.set_ui_state(True))
                return
            status_text = f"Adding {len(all_documents):,} document chunks to '{collection_name}'..."
            self.gui_queue.put(lambda text=status_text: self.status_label.config(text=text))
            batch_size = 100
            self.gui_queue.put(lambda: self.progress.config(maximum=(len(all_documents) - 1) // batch_size + 1, value=0))
            existing_count = collection.count()
            ids = [str(i) for i in range(existing_count, existing_count + len(all_documents))]
            for i in range(0, len(all_documents), batch_size):
                collection.add(ids=ids[i:i+batch_size], documents=all_documents[i:i+batch_size], metadatas=all_metadatas[i:i+batch_size])
                self.gui_queue.put(lambda: self.progress.step())
            elapsed = time.time() - start_time
            final_count = collection.count()
            added_count = final_count - existing_count
            msg = f"Vectorization complete!\n\nFiles Processed: {len(supported_files)}\nChunks Added: {added_count:,}\nTotal in Collection: {final_count:,}\nTime Elapsed: {elapsed:.2f}s"
            self.gui_queue.put(lambda: Messagebox.show_info(msg, "Success"))
            self.gui_queue.put(self.reset_ui)
        except Exception as e:
            logger.error(f"Vectorization failed: {e}", exc_info=True)
            error_msg = f"An error occurred: {e}"
            self.gui_queue.put(lambda msg=error_msg: Messagebox.show_error(msg, "Error"))
            self.gui_queue.put(lambda: self.status_label.config(text="Error! See log for details."))
        finally:
            self.gui_queue.put(lambda: self.progress.config(value=0))
            self.gui_queue.put(lambda: self.set_ui_state(True))
    
    def refresh_collections_list(self):
        def refresh():
            for item in self.collections_list.get_children():
                self.collections_list.delete(item)
            
            collections = self.collection_manager.list_collections()
            
            if not collections:
                self.collections_list.insert("", "end", values=("No collections found", "-", "Empty"))
                self.total_collections_var.set("0")
                self.total_chunks_var.set("0")
                return
            
            total_chunks = 0
            for collection_name in collections:
                info = self.collection_manager.get_collection_info(collection_name)
                total_chunks += info.get("count", 0)
                status = "Active" if info.get("exists", False) else "Error"
                self.collections_list.insert("", "end", values=(collection_name, f"{info.get('count', 0):,}", status))
            
            self.total_collections_var.set(str(len(collections)))
            self.total_chunks_var.set(f"{total_chunks:,}")
        
        threading.Thread(target=refresh, daemon=True).start()
    
    def on_collection_select(self, event):
        selection = self.collections_list.selection()
        if selection:
            item = self.collections_list.item(selection[0])
            values = item['values']
            if values and values[0] != "No collections found":
                collection_name = values[0]
                chunk_count = values[1]
                self.selected_collection_var.set(collection_name)
                self.selected_count_var.set(chunk_count)
                self.rename_collection_button.config(state="normal")
                self.delete_collection_button.config(state="normal")
            else:
                self.selected_collection_var.set("None")
                self.selected_count_var.set("0")
                self.rename_collection_button.config(state="disabled")
                self.delete_collection_button.config(state="disabled")
        else:
            self.selected_collection_var.set("None")
            self.selected_count_var.set("0")
            self.rename_collection_button.config(state="disabled")
            self.delete_collection_button.config(state="disabled")
    
    def rename_selected_collection(self):
        old_name = self.selected_collection_var.get()
        if old_name == "None":
            Messagebox.show_warning("No collection selected.", "Selection Required")
            return
        
        dialog = ttk.Toplevel(self)
        dialog.title("Rename Collection")
        dialog.geometry("550x450")
        dialog.transient(self)
        dialog.grab_set()
        
        dialog.update_idletasks()
        x = self.winfo_x() + (self.winfo_width() // 2) - (dialog.winfo_width() // 2)
        y = self.winfo_y() + (self.winfo_height() // 2) - (dialog.winfo_height() // 2)
        dialog.geometry(f"+{x}+{y}")
        
        main_frame = ttk.Frame(dialog, padding=20)
        main_frame.pack(fill="both", expand=True)
        
        info_frame = ttk.LabelFrame(main_frame, text="Current Collection")
        info_frame.pack(fill="x", pady=(0, 15))
        
        info_inner = ttk.Frame(info_frame, padding=10)
        info_inner.pack(fill="both", expand=True)
        
        name_row = ttk.Frame(info_inner)
        name_row.pack(fill="x", pady=5)
        ttk.Label(name_row, text="Name:", font=("TkDefaultFont", 9, "bold"), width=12).pack(side="left")
        ttk.Label(name_row, text=old_name, foreground="blue", font=("TkDefaultFont", 9)).pack(side="left")
        
        chunks_row = ttk.Frame(info_inner)
        chunks_row.pack(fill="x", pady=5)
        ttk.Label(chunks_row, text="Chunks:", font=("TkDefaultFont", 9, "bold"), width=12).pack(side="left")
        ttk.Label(chunks_row, text=self.selected_count_var.get(), font=("TkDefaultFont", 9)).pack(side="left")
        
        rules_frame = ttk.LabelFrame(main_frame, text="Naming Rules")
        rules_frame.pack(fill="x", pady=(0, 15))
        
        rules_inner = ttk.Frame(rules_frame, padding=10)
        rules_inner.pack(fill="both", expand=True)
        
        rules_text = """• Allowed characters: letters (a-z, A-Z), numbers (0-9), hyphens (-), underscores (_)
        • No spaces or special characters allowed
        • Minimum length: 3 characters
        • Maximum length: 63 characters"""
        
        rules_label = ttk.Label(rules_inner, text=rules_text, font=("TkDefaultFont", 8), justify="left")
        rules_label.pack(anchor="w")
        
        input_frame = ttk.LabelFrame(main_frame, text="New Collection Name")
        input_frame.pack(fill="x", pady=(0, 15))
        
        input_inner = ttk.Frame(input_frame, padding=10)
        input_inner.pack(fill="both", expand=True)
        
        self.rename_entry = ttk.Entry(input_inner, width=50, font=("TkDefaultFont", 10))
        self.rename_entry.pack(fill="x", pady=(0, 10))
        self.rename_entry.focus()
        
        self.rename_validation_label = ttk.Label(input_inner, text="", foreground="red", font=("TkDefaultFont", 8))
        self.rename_validation_label.pack(fill="x")
        
        def validate_rename_input(event=None):
            name = self.rename_entry.get().strip()
            if name:
                is_valid, error_msg = CollectionManager.validate_collection_name(name)
                if not is_valid:
                    self.rename_validation_label.config(text=error_msg, foreground="red")
                    return False
                else:
                    self.rename_validation_label.config(text="Valid collection name", foreground="green")
                    return True
            else:
                self.rename_validation_label.config(text="")
                return False
        
        self.rename_entry.bind("<KeyRelease>", validate_rename_input)
        
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill="x", pady=(10, 0))
        
        def do_rename():
            new_name = self.rename_entry.get().strip()
            if not new_name:
                Messagebox.show_warning("Please enter a valid collection name.", "Invalid Name")
                return
            
            is_valid, error_msg = CollectionManager.validate_collection_name(new_name)
            if not is_valid:
                Messagebox.show_warning(error_msg, "Invalid Collection Name")
                return
            
            sanitized_name = CollectionManager.sanitize_collection_name(new_name)
            
            if sanitized_name != new_name:
                result = Messagebox.yesno(
                    f"The name will be sanitized to follow naming rules:\n\n"
                    f"Original: '{new_name}'\n"
                    f"Sanitized: '{sanitized_name}'\n\n"
                    f"Do you want to continue?",
                    "Name Will Be Sanitized"
                )
                if result != "Yes":
                    return
            
            if sanitized_name == old_name:
                dialog.destroy()
                return
            
            dialog.destroy()
            
            def rename_worker():
                self.gui_queue.put(lambda: self.status_bar.config(text=f"Renaming collection '{old_name}' to '{sanitized_name}'..."))
                self.gui_queue.put(lambda: self.set_ui_state(False))
                
                success, message = self.collection_manager.rename_collection(old_name, sanitized_name)
                
                if success:
                    self.gui_queue.put(lambda: Messagebox.show_info(message, "Success"))
                    self.gui_queue.put(lambda: self.refresh_collections_list())
                    self.gui_queue.put(lambda: self.status_bar.config(text=message))
                else:
                    self.gui_queue.put(lambda: Messagebox.showerror(message, "Error"))
                    self.gui_queue.put(lambda: self.status_bar.config(text="Rename failed"))
                
                self.gui_queue.put(lambda: self.set_ui_state(True))
            
            threading.Thread(target=rename_worker, daemon=True).start()
        
        cancel_btn = ttk.Button(button_frame, text="Cancel", command=dialog.destroy, bootstyle="secondary", width=12)
        cancel_btn.pack(side="right", padx=5)
        
        rename_btn = ttk.Button(button_frame, text="Rename Collection", command=do_rename, bootstyle="primary", width=15)
        rename_btn.pack(side="right", padx=5)
        
        self.rename_entry.bind("<Return>", lambda e: do_rename())
    
    def delete_selected_collection(self):
        selected_name = self.selected_collection_var.get()
        if selected_name == "None":
            Messagebox.show_warning("No collection selected.", "Selection Required")
            return
        
        result = Messagebox.yesno(
            f"Are you sure you want to delete collection '{selected_name}'?\n\n"
            f"This action cannot be undone and will permanently remove all {self.selected_count_var.get()} document chunks.",
            "Confirm Deletion"
        )
        
        if result == "Yes":
            def delete_worker():
                self.gui_queue.put(lambda: self.status_bar.config(text=f"Deleting collection '{selected_name}'..."))
                self.gui_queue.put(lambda: self.set_ui_state(False))
                
                success, message = self.collection_manager.delete_collection(selected_name)
                
                if success:
                    self.gui_queue.put(lambda: Messagebox.show_info(message, "Success"))
                    self.gui_queue.put(lambda: self.refresh_collections_list())
                    self.gui_queue.put(lambda: self.selected_collection_var.set("None"))
                    self.gui_queue.put(lambda: self.selected_count_var.set("0"))
                    self.gui_queue.put(lambda: self.rename_collection_button.config(state="disabled"))
                    self.gui_queue.put(lambda: self.delete_collection_button.config(state="disabled"))
                    self.gui_queue.put(lambda: self.status_bar.config(text=message))
                else:
                    self.gui_queue.put(lambda: Messagebox.showerror(message, "Error"))
                    self.gui_queue.put(lambda: self.status_bar.config(text="Deletion failed"))
                
                self.gui_queue.put(lambda: self.set_ui_state(True))
            
            threading.Thread(target=delete_worker, daemon=True).start()

def run_gui():
    app = DataVectorizerApp()
    app.mainloop()

if __name__ == "__main__":
    run_gui()