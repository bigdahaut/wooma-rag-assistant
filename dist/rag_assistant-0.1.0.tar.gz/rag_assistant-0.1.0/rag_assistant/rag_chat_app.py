# from hardware_lock import verify_license, LicenseError
import sys
# try:
#     verify_license()
# except LicenseError as e:
#     print(f"\n{'='*50}")
#     print(f"  LICENSE ERROR")
#     print(f"{'='*50}")
#     print(f"  {e}")
#     print(f"{'='*50}\n")
#     sys.exit(1)
import json
import logging
import os
import uuid
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Any

import chromadb
import requests
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, StreamingResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

# ── Nuitka onefile asset path resolver ───────────────────────────────────────
def get_asset_path(relative_path: str) -> str:
    base = os.path.dirname(os.path.abspath(__file__))
    full = os.path.join(base, relative_path)
    if os.path.exists(full):
        return full
    alt = os.path.join(os.path.dirname(os.path.abspath(sys.executable)), relative_path)
    if os.path.exists(alt):
        return alt
    return full
# ─────────────────────────────────────────────────────────────────────────────

app = FastAPI()

app.mount("/css",   StaticFiles(directory=get_asset_path("css")),   name="css")
app.mount("/js",    StaticFiles(directory=get_asset_path("js")),    name="js")
app.mount("/fonts", StaticFiles(directory=get_asset_path("fonts")), name="fonts")

@app.get('/favicon.ico', include_in_schema=False)
async def favicon():
    favicon_path = get_asset_path('favicon.ico')
    if os.path.exists(favicon_path):
        return FileResponse(favicon_path)
    raise HTTPException(status_code=404, detail="Favicon not found")

# --- Configuration ---
CHROMA_PERSIST_DIRECTORY = "chroma_storage"
CHATS_HISTORY_DIRECTORY = "chats_history"
OLLAMA_BASE_URL = "http://localhost:11434"

# --- Setup ---
os.makedirs(CHATS_HISTORY_DIRECTORY, exist_ok=True)
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# --- Pydantic Models ---
class ChatMessage(BaseModel):
    model: str
    collection: str
    prompt: str
    chat_id: str | None = None
    temperature: float = 0.3 

class ChatHistory(BaseModel):
    chat_id: str
    timestamp: str
    title: str
    messages: List[Dict[str, Any]]

# --- Helper Functions ---
def generate_chat_title(user_prompt: str) -> str:
    cleaned = user_prompt.strip()
    if not cleaned:
        return "Sans titre"
    cleaned = ' '.join(cleaned.split())
    sentences = cleaned.split('.')
    first_sentence = sentences[0].strip()
    words = first_sentence.split()
    if len(words) > 7:
        return ' '.join(words[:7]) + '...'
    return first_sentence

async def generate_ai_title(prompt: str, model: str) -> str:
    try:
        response = requests.post(
            f"{OLLAMA_BASE_URL}/api/generate",
            json={
                "model": model,
                "prompt": f"Générez un titre très court (3-5 mots) pour cette conversation: {prompt}. Répondez uniquement avec le titre en français.",
                "stream": False,
                "options": {
                    "temperature": 0.3,
                    "num_predict": 20
                }
            },
            timeout=300
        )
        response.raise_for_status()
        title = response.json().get("response", "").strip('"\'')
        title = title.replace('\n', ' ').replace('"', '').replace("'", "")
        return title if title and len(title) < 50 else generate_chat_title(prompt)
    except Exception as e:
        logger.warning(f"AI title generation failed: {e}")
        return generate_chat_title(prompt)

def get_date_category(timestamp_str: str) -> str:
    try:
        dt = datetime.fromisoformat(timestamp_str)
        now = datetime.now()
        today = now.replace(hour=0, minute=0, second=0, microsecond=0)
        yesterday = today - timedelta(days=1)
        last_week = today - timedelta(days=7)
        last_month = today - timedelta(days=30)
        
        if dt >= today:
            return "Aujourd'hui"
        elif dt >= yesterday:
            return "Hier"
        elif dt >= last_week:
            return "La semaine dernière"
        elif dt >= last_month:
            return "Mois dernier"
        else:
            return "Plus anciens"
    except Exception:
        return "Plus anciens"

# --- API Endpoints ---
@app.get("/api/collections", response_model=List[str])
async def list_collections():
    try:
        client = chromadb.PersistentClient(path=CHROMA_PERSIST_DIRECTORY)
        collections = [collection.name for collection in client.list_collections()]
        return collections
    except Exception as e:
        logger.error(f"Error connecting to ChromaDB: {e}")
        raise HTTPException(status_code=503, detail="Could not connect to ChromaDB.")

@app.get("/api/models", response_model=List[str])
async def list_models():
    try:
        response = requests.get(f"{OLLAMA_BASE_URL}/api/tags", timeout=5)
        response.raise_for_status()
        models_data = response.json().get("models", [])
        return [m["name"] for m in models_data if not any(t in m["name"].lower() for t in ["embed", "embedding"])]
    except requests.exceptions.RequestException as e:
        logger.error(f"Error connecting to Ollama: {e}")
        raise HTTPException(status_code=503, detail="Could not connect to Ollama.")

@app.get("/api/config")
async def get_config():
    """Retourne la configuration définie au lancement du serveur"""
    return {
        "default_model": os.environ.get("RAG_DEFAULT_MODEL", "")
    }

# --- Chat History Management ---
def load_chat_history(chat_id: str) -> ChatHistory:
    filepath = Path(CHATS_HISTORY_DIRECTORY) / f"{chat_id}.json"
    if not filepath.exists():
        raise HTTPException(status_code=404, detail="Chat not found")
    try:
        with open(filepath, "r", encoding='utf-8') as f:
            return ChatHistory(**json.load(f))
    except json.JSONDecodeError as e:
        logger.error(f"Corrupted chat file {chat_id}: {e}")
        raise HTTPException(status_code=500, detail="Chat file is corrupted")

def save_chat_history(chat_history: ChatHistory):
    filepath = Path(CHATS_HISTORY_DIRECTORY) / f"{chat_history.chat_id}.json"
    with open(filepath, "w") as f:
        json.dump(chat_history.model_dump(), f, indent=2)

def get_system_prompt_template() -> str:
    return (
        "Vous êtes un assistant IA professionnel, précis et fiable.\n"
        "Vous devez répondre aux questions UNIQUEMENT en vous basant sur le contexte fourni ci-dessous.\n\n"
        "RÈGLES STRICTES À SUIVRE :\n"
        "1. Si la réponse se trouve DANS le contexte, fournissez une réponse précise et complète en français.\n"
        "2. Si le contexte ne contient PAS l'information demandée, dites clairement: "
        "'Je ne dispose pas d'information suffisante dans les documents fournis pour répondre à cette question.'\n"
        "3. N'inventez JAMAIS d'informations. Ne faites pas de suppositions. Ne complétez pas avec vos connaissances générales.\n"
        "4. Citez les sources lorsque c'est pertinent en vous basant sur les métadonnées fournies.\n"
        "5. Répondez directement sans préambule comme 'Selon le contexte' ou 'D'après les documents' - allez droit au but.\n"
        "6. Utilisez le formatage Markdown pour une meilleure lisibilité (titres, listes, puces, gras pour les points importants).\n"
        "7. Si vous n'êtes PAS SÛR à 100% d'une information basée sur le contexte, n'incluez pas cette information.\n"
        "8. Structurez vos réponses de manière claire et logique.\n"
        "9. IMPORTANT: N'utilisez PAS les balises <|think|> et n'effectuez PAS d'étapes de raisonnement interne. "
        "Ne produisez que la réponse finale directement, sans réflexion visible.\n"
        "10. no_think: Vous devez répondre immédiatement sans aucune pensée ou raisonnement affiché.\n\n"
        "CONTEXTE FOURNI :\n{context}\n\n"
        "RAPPEL : Ne répondez qu'à partir de ce contexte. Si l'information n'y est pas, dites-le honnêtement. "
        "Répondez directement - pas de balises <|think|>, pas de raisonnement interne, juste la réponse finale. "
        "Ne jamais exposer un mot de passe. Toujours le remplacer par 'votremotdepassesecurise' "
        "Toujours la valeur de 'WEBHOOK_SECRET' par 'YOUR_WEBHOOK_TOKEN'"
    )

def build_rag_prompt(query: str, context: List[str]) -> List[Dict[str, str]]:
    context_text = "\n---\n".join(context) if context else "Aucun contexte disponible pour cette question."
    formatted_system_prompt = get_system_prompt_template().format(context=context_text)
    
    return [
        {"role": "system", "content": formatted_system_prompt},
        {"role": "user", "content": f"Question: {query}"}
    ]

def build_conversation_messages(query: str, context: List[str], chat_history: List[Dict[str, Any]]) -> List[Dict[str, str]]:
    context_text = "\n---\n".join(context) if context else "Aucun contexte disponible pour cette question."
    formatted_system_prompt = get_system_prompt_template().format(context=context_text)
    
    messages = [{"role": "system", "content": formatted_system_prompt}]
    recent_history = chat_history[-20:] if len(chat_history) > 20 else chat_history
    
    for msg in recent_history:
        if msg.get("role") in ["user", "assistant"]:
            messages.append({"role": msg["role"], "content": msg.get("content", "")})
    
    messages.append({"role": "user", "content": f"Question: {query}"})
    return messages

def stream_ollama_chat(messages: List[Dict[str, str]], model: str, temperature: float = 0.3):
    try:
        response = requests.post(
            f"{OLLAMA_BASE_URL}/api/chat",
            json={
                "model": model,
                "messages": messages,
                "stream": True,
                "options": {
                    "temperature": temperature,
                    "top_k": 40 if temperature > 0 else 1,
                    "top_p": 0.9 if temperature > 0 else 1.0,
                    "repeat_penalty": 1.1,
                    "num_predict": 2048,
                    "stop": ["<|im_end|>", "<|end|>"]
                }
            },
            stream=True,
            timeout=300
        )
        response.raise_for_status()
        for line in response.iter_lines():
            if line:
                try:
                    chunk = json.loads(line)
                    if "message" in chunk and "content" in chunk["message"]:
                        yield chunk["message"]["content"]
                except json.JSONDecodeError:
                    continue
    except requests.exceptions.RequestException as e:
        logger.error(f"Streaming error: {e}")
        yield f"❌ Erreur de connexion à Ollama : {e}"

@app.get("/api/chats", response_model=List[Dict[str, str]])
async def list_chats():
    chats = []
    for filename in os.listdir(CHATS_HISTORY_DIRECTORY):
        if filename.endswith(".json"):
            try:
                chat_id = filename.replace(".json", "")
                chat_data = load_chat_history(chat_id)
                chats.append({
                    "chat_id": chat_data.chat_id, 
                    "title": chat_data.title,
                    "timestamp": chat_data.timestamp
                })
            except Exception:
                continue
    chats.sort(key=lambda x: x.get("timestamp", ""), reverse=True)
    return [{"chat_id": c["chat_id"], "title": c["title"]} for c in chats]

@app.get("/api/chats/grouped", response_model=Dict[str, List[Dict[str, str]]])
async def list_chats_grouped():
    grouped_chats = {
        "Aujourd'hui": [],
        "Hier": [],
        "La semaine dernière": [],
        "Mois dernier": [],
        "Plus anciens": []
    }
    
    for filename in os.listdir(CHATS_HISTORY_DIRECTORY):
        if filename.endswith(".json"):
            try:
                chat_id = filename.replace(".json", "")
                chat_data = load_chat_history(chat_id)
                category = get_date_category(chat_data.timestamp)
                grouped_chats[category].append({
                    "chat_id": chat_data.chat_id,
                    "title": chat_data.title,
                    "timestamp": chat_data.timestamp
                })
            except Exception:
                continue
    
    for category in grouped_chats:
        grouped_chats[category].sort(key=lambda x: x.get("timestamp", ""), reverse=True)
    return grouped_chats

@app.get("/api/chats/{chat_id}", response_model=ChatHistory)
async def get_chat(chat_id: str):
    return load_chat_history(chat_id)

@app.delete("/api/chats/{chat_id}", status_code=204)
async def delete_chat(chat_id: str):
    filepath = Path(CHATS_HISTORY_DIRECTORY) / f"{chat_id}.json"
    if filepath.exists():
        filepath.unlink()
    else:
        raise HTTPException(status_code=404, detail="Chat not found")

@app.delete("/api/chats", status_code=204)
async def delete_all_chats():
    try:
        deleted_count = 0
        for filename in os.listdir(CHATS_HISTORY_DIRECTORY):
            if filename.endswith(".json"):
                filepath = Path(CHATS_HISTORY_DIRECTORY) / filename
                filepath.unlink()
                deleted_count += 1
        logger.info(f"Deleted {deleted_count} chat histories")
        return None
    except Exception as e:
        logger.error(f"Error deleting all chats: {e}")
        raise HTTPException(status_code=500, detail=f"Error deleting chats: {e}")

@app.post("/api/chat")
async def chat(message: ChatMessage):
    try:
        client = chromadb.PersistentClient(path=CHROMA_PERSIST_DIRECTORY)
        collection = client.get_collection(name=message.collection)
        results = collection.query(
            query_texts=[message.prompt],
            n_results=5,
            include=["documents", "metadatas", "distances"]
        )
        
        documents = results.get("documents", [[]])
        context = documents[0] if documents and len(documents) > 0 else []
        
        metadatas_list = results.get("metadatas", [[]])
        metadatas = metadatas_list[0] if metadatas_list and len(metadatas_list) > 0 else []
        
        distances_list = results.get("distances", [[]])
        distances = distances_list[0] if distances_list and len(distances_list) > 0 else []
        
        sources = []
        for i, meta in enumerate(metadatas):
            filename = meta.get("filename", "Unknown") if meta else "Unknown"
            if i < len(distances) and distances[i] < 1.5:
                sources.append(filename)
        
        sources = sorted(list(set(sources)))
        logger.info(f"Query: {message.prompt[:100]}... | Retrieved {len(context)} chunks | Sources: {sources}")
        
    except Exception as e:
        logger.error(f"ChromaDB query error: {e}")
        raise HTTPException(status_code=500, detail=f"Erreur de recherche dans la base de données: {e}")

    is_new_chat = not message.chat_id
    chat_id = message.chat_id or str(uuid.uuid4())
    
    chat_history = (
        load_chat_history(chat_id)
        if not is_new_chat
        else ChatHistory(
            chat_id=chat_id,
            timestamp=datetime.now().isoformat(),
            title=await generate_ai_title(message.prompt, message.model),
            messages=[]
        )
    )
    
    messages = build_conversation_messages(message.prompt, context, chat_history.messages)
    chat_history.messages.append({"role": "user", "content": message.prompt})
    
    async def response_generator(chat_id_param=chat_id, is_new_chat_param=is_new_chat, sources_param=sources):
        initial_data = {"sources": sources_param}
        if is_new_chat_param:
            initial_data["chat_id"] = chat_id_param
        yield json.dumps(initial_data, ensure_ascii=False) + "\n"

        full_response = ""
        try:
            for chunk in stream_ollama_chat(messages, message.model, message.temperature):
                full_response += chunk
                yield json.dumps({"chunk": chunk}, ensure_ascii=False) + "\n"

            assistant_message = {
                "role": "assistant",
                "content": full_response,
                "sources": sources_param
            }
            chat_history.messages.append(assistant_message)
            save_chat_history(chat_history)
        except Exception as e:
            logger.error(f"Error during response generation: {e}")
            error_msg = "Désolé, une erreur technique s'est produite. Veuillez réessayer."
            yield json.dumps({"error": error_msg}, ensure_ascii=False) + "\n"

    return StreamingResponse(response_generator(), media_type="application/x-ndjson")

# --- Frontend HTML ---
@app.get("/", response_class=HTMLResponse)
async def get_index(request: Request):
    root_path = request.scope.get("root_path", "")
    
    html_content =  """
    <!DOCTYPE html>
    <html lang="fr">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
        <title>RAG Chat Application - Assistant IA</title>
        <link rel="icon" type="image/x-icon" href="/favicon.ico">
        <style>
            :root {
                --sidebar-bg: #1a1f2b;
                --main-bg: #f8f9fc;
                --accent-color: #4f46e5;
                --accent-hover: #4338ca;
                --hover-color: #2d3748;
                --text-light: #f3f4f6;
                --text-dark: #1f2937;
                --text-muted: #6b7280;
                --border-color: #e5e7eb;
                --error-color: #ef4444;
                --success-color: #10b981;
                --warning-color: #f59e0b;
                --card-bg: #ffffff;
                --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
                --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
                --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
                --code-bg: #1e1e1e;
                --code-color: #d4d4d4;
            }
            * {
                box-sizing: border-box;
            }
            @font-face {
                font-family: 'Inter';
                src: url('/fonts/inter-regular.woff2') format('woff2');
                font-weight: normal;
                font-style: normal;
            }
            body {
                font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
                margin: 0;
                display: flex;
                height: 100vh;
                background-color: var(--main-bg);
                overflow: hidden;
            }
            ::-webkit-scrollbar { width: 8px; height: 8px; }
            ::-webkit-scrollbar-track { background: #f1f1f1; border-radius: 4px; }
            ::-webkit-scrollbar-thumb { background: #c1c1c1; border-radius: 4px; }
            ::-webkit-scrollbar-thumb:hover { background: #a8a8a8; }
            
            #sidebar { width: 280px; background: var(--sidebar-bg); color: var(--text-light); display: flex; flex-direction: column; padding: 20px 16px; border-right: 1px solid rgba(255,255,255,0.1); transition: transform 0.3s ease; z-index: 10; }
            #sidebar h2 { margin: 0 0 24px 0; font-size: 1.5em; font-weight: 600; letter-spacing: -0.5px; background: linear-gradient(135deg, #fff 0%, #a5b4fc 100%); -webkit-background-clip: text; background-clip: text; color: transparent; text-align: center; }
            #new-chat-btn { background: linear-gradient(135deg, var(--accent-color), var(--accent-hover)); color: white; border: none; padding: 12px 16px; border-radius: 12px; cursor: pointer; margin-bottom: 12px; width: 100%; font-size: 0.95em; font-weight: 500; display: flex; align-items: center; justify-content: center; gap: 10px; transition: all 0.2s ease; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
            #new-chat-btn:hover { transform: translateY(-1px); box-shadow: 0 4px 8px rgba(0,0,0,0.2); }
            #delete-all-chats-btn { background: rgba(239, 68, 68, 0.9); color: white; border: none; padding: 10px 16px; border-radius: 12px; cursor: pointer; margin-bottom: 20px; width: 100%; font-size: 0.9em; font-weight: 500; display: flex; align-items: center; justify-content: center; gap: 10px; transition: all 0.2s ease; }
            #delete-all-chats-btn:hover { background: var(--error-color); transform: translateY(-1px); box-shadow: 0 4px 8px rgba(0,0,0,0.2); }
            #chat-list-container { list-style: none; padding: 0; margin: 0 0 24px 0; overflow-y: auto; flex-grow: 1; }
            .chat-group { margin-bottom: 20px; }
            .chat-group-header { font-size: 0.75em; text-transform: uppercase; letter-spacing: 1px; color: rgba(255,255,255,0.5); padding: 8px 0 4px 12px; font-weight: 600; }
            .chat-list-item { padding: 12px 12px; cursor: pointer; border-radius: 10px; margin-bottom: 4px; display: flex; justify-content: space-between; align-items: center; transition: background 0.2s; }
            .chat-list-item:hover, .chat-list-item.active { background: rgba(255,255,255,0.1); }
            .chat-title-container { display: flex; align-items: center; gap: 10px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; flex: 1; min-width: 0; }
            .chat-title-container span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
            .delete-chat { background: none; border: none; color: #f87171; cursor: pointer; font-size: 1.1em; visibility: hidden; opacity: 0; transition: all 0.2s; padding: 4px 8px; border-radius: 6px; }
            .delete-chat:hover { background: rgba(248,113,113,0.2); }
            .chat-list-item:hover .delete-chat { visibility: visible; opacity: 1; }
            
            #menu-toggle { display: none; position: fixed; top: 16px; left: 16px; z-index: 20; background: var(--accent-color); border: none; color: white; width: 44px; height: 44px; border-radius: 12px; cursor: pointer; align-items: center; justify-content: center; box-shadow: var(--shadow-md); }
            #main-content { flex-grow: 1; display: flex; flex-direction: column; height: 100vh; min-width: 0; }
            #header { padding: 16px 24px; background: var(--card-bg); border-bottom: 1px solid var(--border-color); display: flex; gap: 16px; align-items: center; flex-shrink: 0; box-shadow: var(--shadow-sm); flex-wrap: wrap; }
            #header select { padding: 10px 14px; border-radius: 10px; border: 1px solid var(--border-color); background: white; font-size: 0.9em; cursor: pointer; flex: 1; min-width: 150px; transition: border 0.2s; }
            #header select:focus { outline: none; border-color: var(--accent-color); box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1); }
            #chat-window { flex-grow: 1; padding: 24px; overflow-y: auto; display: flex; flex-direction: column; background: var(--main-bg); }
            
            .message { max-width: 85%; padding: 12px 20px; border-radius: 20px; line-height: 1.5; word-wrap: break-word; margin-bottom: 12px; box-shadow: var(--shadow-sm); position: relative; }
            .copy-button { position: absolute; top: 12px; right: 12px; background: white; border: 1px solid #e1e4e8; border-radius: 6px; padding: 4px 10px; cursor: pointer; font-size: 0.7em; font-weight: 500; color: #57606a; opacity: 0; transition: all 0.2s ease; display: flex; align-items: center; gap: 5px; z-index: 10; font-family: inherit; line-height: 1; }
            .copy-button svg { width: 12px; height: 12px; }
            .assistant-turn:hover .copy-button { opacity: 1; }
            .copy-button:hover { background: var(--accent-color); color: white; border-color: var(--accent-color); transform: scale(1.02); box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
            .copy-button.copied { background: var(--success-color); color: white; border-color: var(--success-color); }
            
            .assistant-message { position: relative; background: var(--card-bg); color: var(--text-dark); border: 1px solid var(--border-color); border-bottom-left-radius: 4px; transition: all 0.2s; overflow-x: auto; padding: 16px 70px 16px 20px; min-height: 50px; }
            .assistant-message h1, .assistant-message h2, .assistant-message h3 { margin-top: 0.5em; margin-bottom: 0.5em; }
            .assistant-message h1 { font-size: 1.5em; }
            .assistant-message h2 { font-size: 1.3em; }
            .assistant-message h3 { font-size: 1.1em; }
            .assistant-message p { margin: 0.5em 0; }
            .assistant-message ul, .assistant-message ol { margin: 0.5em 0; padding-left: 1.5em; }
            .assistant-message li { margin: 0.2em 0; }
            
            .assistant-message pre { background: #f6f8fa; border: 1px solid #e1e4e8; border-radius: 8px; padding: 16px; overflow-x: auto; margin: 1em 0; position: relative; box-shadow: 0 1px 2px rgba(0,0,0,0.05); }
            .assistant-message pre:hover { box-shadow: 0 2px 4px rgba(0,0,0,0.1); transition: box-shadow 0.2s ease; }
            .assistant-message pre code { font-family: 'SF Mono', 'Monaco', 'Inconsolata', 'Fira Code', 'Courier New', monospace; font-size: 0.85em; line-height: 1.5; color: #24292e; background: transparent; padding: 0; border: none; }
            .assistant-message code:not(pre code) { background: #f1f3f4; padding: 0.2em 0.4em; border-radius: 4px; font-family: 'SF Mono', 'Monaco', 'Inconsolata', 'Fira Code', 'Courier New', monospace; font-size: 0.85em; color: #d73a49; border: 1px solid #eaecef; }
            .assistant-message p code { background: #f1f3f4; padding: 0.2em 0.4em; border-radius: 4px; font-size: 0.9em; }
            .assistant-message pre::before { content: attr(data-lang); position: absolute; top: 8px; right: 12px; font-size: 0.7em; color: #6a737d; font-family: monospace; text-transform: uppercase; letter-spacing: 0.5px; }
            
            .hljs { background: #f6f8fa !important; color: #24292e !important; }
            .hljs-keyword { color: #d73a49 !important; font-weight: 600; }
            .hljs-string { color: #032f62 !important; }
            .hljs-comment { color: #6a737d !important; font-style: italic; }
            .hljs-function { color: #6f42c1 !important; }
            .hljs-number { color: #005cc5 !important; }
            .hljs-operator { color: #d73a49 !important; }
            .hljs-class { color: #6f42c1 !important; }
            .hljs-variable { color: #e36209 !important; }
            .hljs-attr { color: #005cc5 !important; }
            .hljs-title { color: #6f42c1 !important; }
            .hljs-built_in { color: #d73a49 !important; }
            .hljs-literal { color: #005cc5 !important; }
            .hljs-type { color: #005cc5 !important; }
            .hljs-params { color: #24292e !important; }
            .hljs-tag { color: #22863a !important; }
            .hljs-name { color: #22863a !important; }
            .hljs-attribute { color: #005cc5 !important; }
            .assistant-message blockquote { border-left: 3px solid var(--accent-color); margin: 0.5em 0; padding-left: 1em; color: var(--text-muted); }
            .assistant-message table { border-collapse: collapse; width: 100%; margin: 0.5em 0; }
            .assistant-message th, .assistant-message td { border: 1px solid var(--border-color); padding: 8px; text-align: left; }
            .assistant-message th { background: #f3f4f6; }
            .assistant-message.highlight { border-color: var(--accent-color); box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.2); }
            
            .user-message { background: var(--accent-color); color: white; align-self: flex-end; margin-bottom: 16px; border-bottom-right-radius: 4px; }
            .assistant-turn { display: flex; flex-direction: column; align-items: flex-start; width: 100%; margin-bottom: 20px; position: relative; }
            .sources-container { font-size: 0.75em; color: var(--text-muted); background-color: #f3f4f6; border-radius: 12px; padding: 10px 16px; margin-top: 8px; max-width: 85%; }
            .sources-container strong { display: block; margin-bottom: 6px; font-size: 0.8em; color: var(--text-dark); }
            .sources-container ul { margin: 0; padding-left: 20px; }
            
            #chat-form-wrapper { flex-shrink: 0; padding: 20px 24px; background: var(--card-bg); border-top: 1px solid var(--border-color); }
            #chat-form { display: flex; gap: 12px; }
            #chat-form input { flex-grow: 1; padding: 14px 18px; border: 1px solid var(--border-color); border-radius: 30px; outline: none; font-size: 0.95em; transition: all 0.2s; }
            #chat-form input:focus { border-color: var(--accent-color); box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1); }
            #chat-form button { background: var(--accent-color); color: white; border: none; padding: 0 28px; border-radius: 30px; cursor: pointer; font-weight: 500; transition: all 0.2s; }
            #chat-form button:hover:not(:disabled) { background: var(--accent-hover); transform: scale(1.02); }
            #chat-form button:disabled { background: #9ca3af; cursor: not-allowed; opacity: 0.6; }
            
            .spinner-container { padding: 12px 0; }
            .spinner { display: inline-flex; align-items: center; }
            .spinner div { width: 10px; height: 10px; background-color: var(--accent-color); border-radius: 50%; margin: 0 4px; animation: bounce 1.4s infinite ease-in-out both; }
            .spinner div:nth-child(1) { animation-delay: -0.32s; }
            .spinner div:nth-child(2) { animation-delay: -0.16s; }
            @keyframes bounce { 0%, 80%, 100% { transform: scale(0); opacity: 0.5; } 40% { transform: scale(1); opacity: 1; } }
            
            #nav-controls { position: fixed; bottom: 100px; right: 30px; display: none; gap: 12px; z-index: 100; }
            .nav-btn { background: rgba(0, 0, 0, 0.6); backdrop-filter: blur(8px); color: white; border: none; border-radius: 50%; width: 44px; height: 44px; cursor: pointer; display: flex; align-items: center; justify-content: center; transition: all 0.2s; }
            .nav-btn:hover { background: var(--accent-color); transform: scale(1.05); }
            
            #custom-confirm-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); backdrop-filter: blur(4px); display: flex; align-items: center; justify-content: center; z-index: 1000; opacity: 0; visibility: hidden; transition: all 0.2s; }
            #custom-confirm-overlay.visible { opacity: 1; visibility: visible; }
            #custom-confirm-box { background: white; padding: 32px; border-radius: 20px; box-shadow: var(--shadow-lg); text-align: center; max-width: 90%; width: 400px; }
            #custom-confirm-box p { margin: 0 0 24px; font-size: 1.1em; color: var(--text-dark); }
            #custom-confirm-box button { border: none; padding: 10px 24px; border-radius: 30px; cursor: pointer; font-size: 0.9em; font-weight: 500; margin: 0 8px; transition: all 0.2s; }
            #confirm-btn-yes { background-color: var(--error-color); color: white; }
            #confirm-btn-yes:hover { background-color: #dc2626; }
            #confirm-btn-no { background-color: #e5e7eb; color: var(--text-dark); }
            #confirm-btn-no:hover { background-color: #d1d5db; }
            
            #avatar-container { margin-top: auto; padding-top: 20px; border-top: 1px solid rgba(255,255,255,0.1); text-align: center; cursor: pointer; transition: opacity 0.2s; }
            #avatar-container:hover { opacity: 0.9; }
            #user-avatar { width: 56px; height: 56px; border-radius: 50%; object-fit: cover; border: 2px solid var(--text-light); margin-bottom: 8px; }
            #avatar-label { font-size: 0.75em; color: var(--text-light); display: block; margin-bottom: 4px; }
            #copyright-text { font-size: 0.7em; color: #9ca3af; display: block; margin-top: 8px; letter-spacing: 0.3px; }
            
            #toast-container { position: fixed; bottom: 20px; right: 20px; z-index: 1000; display: flex; flex-direction: column; gap: 8px; }
            .toast { padding: 12px 20px; background: white; color: var(--text-dark); border-radius: 12px; box-shadow: var(--shadow-lg); margin-bottom: 0; opacity: 0; transform: translateX(100%); transition: all 0.3s ease; font-size: 0.9em; font-weight: 500; border-left: 4px solid var(--success-color); }
            .toast.error { border-left-color: var(--error-color); }
            .toast.warning { border-left-color: var(--warning-color); }
            .toast.show { opacity: 1; transform: translateX(0); }
            .empty-state { text-align: center; color: var(--text-muted); margin-top: 80px; font-size: 0.95em; }
            
            @media (max-width: 768px) {
                #sidebar { position: fixed; left: 0; top: 0; height: 100%; transform: translateX(-100%); width: 280px; z-index: 15; box-shadow: 2px 0 10px rgba(0,0,0,0.2); }
                #sidebar.open { transform: translateX(0); }
                #menu-toggle { display: flex; }
                #main-content { margin-left: 0; }
                .message { max-width: 95%; }
                .sources-container { max-width: 95%; }
                #header { padding: 12px 16px; gap: 8px; }
                #header select { font-size: 0.85em; padding: 8px 12px; min-width: 120px; }
                #chat-window { padding: 16px; }
                #chat-form-wrapper { padding: 12px 16px; }
                #chat-form input { padding: 12px 16px; font-size: 0.9em; }
                #chat-form button { padding: 0 20px; }
                .nav-btn { width: 36px; height: 36px; }
                #nav-controls { bottom: 80px; right: 16px; }
            }
        </style>
        <link rel="stylesheet" href="/css/highlight.min.css">
        <script src="/js/highlight.min.js"></script>
        <link href="/css/fonts.css" rel="stylesheet">
        <script src="/js/marked.min.js"></script>
    </head>
    <body>
        <button id="menu-toggle" aria-label="Menu">☰</button>
        <div id="sidebar">
            <h2><span style="color: transparent; text-shadow: 0 0 0 #f97316;">✨</span> RAG Assistant</h2>
            <button id="new-chat-btn" title="Nouvelle conversation">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                <span>Nouveau Chat</span>
            </button>
            <button id="delete-all-chats-btn" title="Supprimer toutes les conversations">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>
                <span>Supprimer tout</span>
            </button>
            <div id="chat-list-container"></div>
            <div id="avatar-container" title="Changer l'avatar">
                <img id="user-avatar" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJub25lIiBzdHJva2U9IiNmZmYiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj48cGF0aCBkPSJNMjAgMjF2LTIxYTIgMiAwIDAgMCAtMiAtMkg2YTIgMiAwIDAgMCAwIDR2MTZhMiAyIDAgMCAwIDIgMnoiPjwvcGF0aD48Y2lyY2xlIGN4PSIxMiIgY3k9IjciIHI9IjQiPjwvY2lyY2xlPjwvc3ZnPg==" alt="User Avatar">
                <span id="avatar-label">Changer l'avatar</span>
                <span id="copyright-text"></span>
                <input type="file" id="avatar-input" accept="image/*" style="display: none;">
            </div>
        </div>
        <div id="main-content">
            <div id="header">
                <select id="collection-select" required><option value="">-- Sélectionner une collection --</option></select>
                <select id="model-select" required><option value="">-- Sélectionner un modèle --</option></select>
                <select id="temperature-select" title="Température de créativité (0.0 = précis, 1.0 = créatif)">
                    <option value="0.0">Temp: 0.0 (Précis)</option>
                    <option value="0.1">Temp: 0.1</option>
                    <option value="0.2">Temp: 0.2</option>
                    <option value="0.3" selected>Temp: 0.3 (Équilibré)</option>
                    <option value="0.4">Temp: 0.4</option>
                    <option value="0.5">Temp: 0.5</option>
                    <option value="0.6">Temp: 0.6</option>
                    <option value="0.7">Temp: 0.7</option>
                    <option value="0.8">Temp: 0.8</option>
                    <option value="0.9">Temp: 0.9</option>
                    <option value="1.0">Temp: 1.0 (Créatif)</option>
                </select>
            </div>
            <div id="chat-window"></div>
            <div id="chat-form-wrapper">
                <form id="chat-form">
                    <input type="text" id="prompt-input" placeholder="Tapez votre message... (en français)" autocomplete="off" disabled>
                    <button type="submit" id="send-btn" disabled>Envoyer</button>
                </form>
            </div>
            <div id="nav-controls">
                <button id="nav-up" class="nav-btn" title="Message précédent"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 15l-6-6-6 6"/></svg></button>
                <button id="nav-down" class="nav-btn" title="Message suivant"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9l6 6 6-6"/></svg></button>
            </div>
        </div>
        <div id="custom-confirm-overlay">
            <div id="custom-confirm-box">
                <p id="confirm-message">Êtes-vous sûr ?</p>
                <button id="confirm-btn-yes">Supprimer</button>
                <button id="confirm-btn-no">Annuler</button>
            </div>
        </div>
        <div id="toast-container"></div>

        <script>
            document.addEventListener('DOMContentLoaded', () => {
                const collectionSelect = document.getElementById('collection-select');
                const modelSelect = document.getElementById('model-select');
                const temperatureSelect = document.getElementById('temperature-select');
                const chatWindow = document.getElementById('chat-window');
                const chatForm = document.getElementById('chat-form');
                const promptInput = document.getElementById('prompt-input');
                const sendBtn = document.getElementById('send-btn');
                const chatListContainer = document.getElementById('chat-list-container');
                const newChatBtn = document.getElementById('new-chat-btn');
                const deleteAllChatsBtn = document.getElementById('delete-all-chats-btn');
                const navControls = document.getElementById('nav-controls');
                const navUpBtn = document.getElementById('nav-up');
                const navDownBtn = document.getElementById('nav-down');
                const confirmOverlay = document.getElementById('custom-confirm-overlay');
                const confirmMessage = document.getElementById('confirm-message');
                const confirmBtnYes = document.getElementById('confirm-btn-yes');
                const confirmBtnNo = document.getElementById('confirm-btn-no');
                const avatarContainer = document.getElementById('avatar-container');
                const userAvatar = document.getElementById('user-avatar');
                const avatarInput = document.getElementById('avatar-input');
                const toastContainer = document.getElementById('toast-container');
                const copyrightSpan = document.getElementById('copyright-text');
                const menuToggle = document.getElementById('menu-toggle');
                const sidebar = document.getElementById('sidebar');

                const currentYear = new Date().getFullYear();
                copyrightSpan.textContent = `©${currentYear} Wooma CI`;

                let currentChatId = null;
                let botMessageElements = [];
                let currentBotMessageIndex = -1;
                let chunkQueue = [];
                let isProcessingQueue = false;
                let pendingDeleteAllCallback = null;

                if (menuToggle) {
                    menuToggle.addEventListener('click', () => {
                        sidebar.classList.toggle('open');
                    });
                    document.addEventListener('click', (e) => {
                        if (window.innerWidth <= 768 && sidebar.classList.contains('open') && 
                            !sidebar.contains(e.target) && e.target !== menuToggle) {
                            sidebar.classList.remove('open');
                        }
                    });
                }

                if (typeof marked !== 'undefined') {
                    marked.setOptions({
                        breaks: true,
                        gfm: true,
                        headerIds: false,
                        mangle: false,
                        highlight: function(code, lang) {
                            if (lang && hljs.getLanguage(lang)) {
                                try {
                                    return hljs.highlight(code, { language: lang }).value;
                                } catch (e) {
                                    console.error('Highlight error:', e);
                                }
                            }
                            return code;
                        }
                    });
                }

                function renderMarkdownWithHighlight(content) {
                    if (typeof marked !== 'undefined') {
                        try {
                            const html = marked.parse(content);
                            setTimeout(() => {
                                document.querySelectorAll('.assistant-message pre code').forEach((block) => {
                                    hljs.highlightElement(block);
                                });
                                document.querySelectorAll('.assistant-message pre').forEach((pre) => {
                                    pre.style.backgroundColor = '#f6f8fa';
                                    pre.style.border = '1px solid #e1e4e8';
                                });
                            }, 0);
                            return html;
                        } catch (e) {
                            console.error('Markdown parsing error:', e);
                            return `<p>${escapeHtml(content)}</p>`;
                        }
                    }
                    return `<p>${escapeHtml(content)}</p>`;
                }

                function escapeHtml(text) {
                    const div = document.createElement('div');
                    div.textContent = text;
                    return div.innerHTML;
                }

                function showToast(message, isError = false, isWarning = false) {
                    const toast = document.createElement('div');
                    toast.className = `toast ${isError ? 'error' : (isWarning ? 'warning' : '')}`;
                    toast.textContent = message;
                    toastContainer.appendChild(toast);
                    
                    setTimeout(() => {
                        toast.classList.add('show');
                        setTimeout(() => {
                            toast.classList.remove('show');
                            setTimeout(() => toast.remove(), 300);
                        }, 3000);
                    }, 10);
                }

                async function copyToClipboard(text, buttonElement) {
                    if (!text) {
                        showToast('Rien à copier', true);
                        return;
                    }
                    try {
                        await navigator.clipboard.writeText(text);
                        const originalHTML = buttonElement.innerHTML;
                        buttonElement.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 6L9 17l-5-5"/></svg> Copié!';
                        buttonElement.classList.add('copied');
                        showToast('Copié dans le presse-papier');
                        setTimeout(() => {
                            buttonElement.innerHTML = originalHTML;
                            buttonElement.classList.remove('copied');
                        }, 2000);
                    } catch (err) {
                        console.error('Clipboard error:', err);
                        const textarea = document.createElement('textarea');
                        textarea.value = text;
                        document.body.appendChild(textarea);
                        textarea.select();
                        document.execCommand('copy');
                        document.body.removeChild(textarea);
                        showToast('Copié (méthode alternative)');
                    }
                }

                function addCopyButtonToMessage(messageDiv, content) {
                    if (!messageDiv || !content) {
                        return;
                    }
                    if (messageDiv.querySelector('.copy-button')) {
                        return;
                    }
                    const copyBtn = document.createElement('button');
                    copyBtn.className = 'copy-button';
                    copyBtn.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg> Copier';
                    copyBtn.title = 'Copier la réponse';
                    
                    copyBtn.onclick = async (e) => {
                        e.stopPropagation();
                        e.preventDefault();
                        try {
                            await copyToClipboard(content, copyBtn);
                        } catch (err) {
                            console.error('Copy failed:', err);
                            showToast('Échec de la copie', true);
                        }
                    };
                    messageDiv.appendChild(copyBtn);
                }

                async function fetchAndPopulate(url, el, defaultOpt, emptyText) {
                    try {
                        const response = await fetch(url);
                        if (!response.ok) {
                            const err = await response.json();
                            throw new Error(err.detail || `HTTP ${response.status}`);
                        }
                        const items = await response.json();
                        el.innerHTML = `<option value="">-- ${defaultOpt} --</option>`;
                        if (items.length === 0) {
                            el.innerHTML = `<option value="">${emptyText}</option>`;
                        } else {
                            items.forEach(item => el.add(new Option(item, item)));
                        }
                    } catch (error) {
                        el.innerHTML = `<option value="">⚠️ Erreur: ${error.message}</option>`;
                        showToast(`Impossible de charger ${defaultOpt.toLowerCase()}: ${error.message}`, true);
                    }
                }

                function checkSelections() {
                    const isReady = collectionSelect.value && modelSelect.value;
                    promptInput.disabled = !isReady;
                    sendBtn.disabled = !isReady;
                    if (!document.querySelector('.message') && !chatWindow.querySelector('.assistant-turn')) {
                        let placeholder = isReady ? "Sélectionnez un chat à gauche ou commencez une nouvelle conversation." : "Veuillez sélectionner une collection et un modèle pour commencer.";
                        chatWindow.innerHTML = `<div class="empty-state">${placeholder}</div>`;
                    }
                }
                
                function updateBotMessageNav() {
                    botMessageElements = Array.from(chatWindow.querySelectorAll('.assistant-message'));
                    currentBotMessageIndex = -1;
                    navControls.style.display = botMessageElements.length >= 2 ? 'flex' : 'none';
                    document.querySelectorAll('.assistant-message.highlight').forEach(el => el.classList.remove('highlight'));
                }

                function navigateBotMessages(direction) {
                    if (botMessageElements.length < 1) return;
                    currentBotMessageIndex += direction;
                    if (currentBotMessageIndex >= botMessageElements.length) currentBotMessageIndex = 0;
                    if (currentBotMessageIndex < 0) currentBotMessageIndex = botMessageElements.length - 1;
                    
                    document.querySelectorAll('.assistant-message.highlight').forEach(el => el.classList.remove('highlight'));
                    const targetElement = botMessageElements[currentBotMessageIndex];
                    targetElement.classList.add('highlight');
                    targetElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }
                
                function showCustomConfirm(chatId, chatTitle, isDeleteAll = false, callback = null) {
                    if (isDeleteAll) {
                        confirmMessage.innerHTML = `Êtes-vous sûr de vouloir supprimer TOUTES les conversations ?<br><br><strong style="color: #ef4444;">Cette action est irréversible !</strong>`;
                        pendingDeleteAllCallback = callback;
                        confirmOverlay.dataset.deleteAll = 'true';
                    } else {
                        confirmMessage.innerHTML = `Êtes-vous sûr de vouloir supprimer la conversation :<br><strong>"${chatTitle}"</strong> ?`;
                        confirmOverlay.dataset.chatId = chatId;
                        confirmOverlay.dataset.deleteAll = 'false';
                    }
                    confirmOverlay.classList.add('visible');
                }

                confirmBtnNo.onclick = () => {
                    confirmOverlay.classList.remove('visible');
                    pendingDeleteAllCallback = null;
                };
                
                confirmBtnYes.onclick = async () => {
                    const isDeleteAll = confirmOverlay.dataset.deleteAll === 'true';
                    
                    if (isDeleteAll) {
                        try {
                            const response = await fetch('/api/chats', { method: 'DELETE' });
                            if (!response.ok) throw new Error('Delete all failed');
                            
                            currentChatId = null;
                            chatWindow.innerHTML = '<div class="empty-state">✨ Toutes les conversations ont été supprimées. Cliquez sur "Nouveau Chat" pour commencer.</div>';
                            
                            chunkQueue = [];
                            isProcessingQueue = false;
                            botMessageElements = [];
                            currentBotMessageIndex = -1;
                            navControls.style.display = 'none';
                            
                            promptInput.value = '';
                            
                            await loadChatsGrouped();
                            showToast('Toutes les conversations ont été supprimées');
                            
                            if (pendingDeleteAllCallback) {
                                pendingDeleteAllCallback();
                                pendingDeleteAllCallback = null;
                            }
                        } catch (error) {
                            console.error("Delete all failed:", error);
                            showToast('Échec de la suppression de toutes les conversations', true);
                        }
                    } else {
                        const chatId = confirmOverlay.dataset.chatId;
                        try {
                            const response = await fetch(`/api/chats/${chatId}`, { method: 'DELETE' });
                            if (!response.ok) throw new Error('Delete failed');
                            
                            if (currentChatId === chatId) {
                                startNewChat();
                            }
                            
                            await loadChatsGrouped();
                            showToast('Conversation supprimée avec succès');
                        } catch (error) {
                            console.error("Delete failed:", error);
                            showToast('Échec de la suppression', true);
                        }
                    }
                    confirmOverlay.classList.remove('visible');
                };

                const scrollToBottom = () => { 
                    chatWindow.scrollTop = chatWindow.scrollHeight; 
                };

                async function loadChatsGrouped() {
                    chatListContainer.innerHTML = '';
                    try {
                        const response = await fetch('/api/chats/grouped');
                        if (!response.ok) throw new Error('Failed to load chats');
                        const groupedChats = await response.json();
                        
                        const categoryOrder = ["Aujourd'hui", "Hier", "La semaine dernière", "Mois dernier", "Plus anciens"];
                        let hasAnyChats = false;
                        
                        for (const category of categoryOrder) {
                            const chats = groupedChats[category];
                            if (chats && chats.length > 0) {
                                hasAnyChats = true;
                                const groupDiv = document.createElement('div');
                                groupDiv.className = 'chat-group';
                                
                                const headerDiv = document.createElement('div');
                                headerDiv.className = 'chat-group-header';
                                headerDiv.textContent = category;
                                groupDiv.appendChild(headerDiv);
                                
                                chats.forEach(chat => {
                                    const li = document.createElement('div');
                                    li.className = 'chat-list-item';
                                    li.dataset.chatId = chat.chat_id;
                                    if (chat.chat_id === currentChatId) li.classList.add('active');
                                    li.innerHTML = `
                                        <div class="chat-title-container" title="${chat.title.replace(/"/g, '&quot;')}">
                                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                                            <span>${chat.title}</span>
                                        </div>
                                        <button class="delete-chat">🗑️</button>
                                    `;
                                    li.querySelector('.delete-chat').onclick = (e) => {
                                        e.stopPropagation();
                                        showCustomConfirm(chat.chat_id, chat.title);
                                    };
                                    li.onclick = () => loadChat(chat.chat_id);
                                    groupDiv.appendChild(li);
                                });
                                
                                chatListContainer.appendChild(groupDiv);
                            }
                        }
                        
                        if (!hasAnyChats) {
                            const emptyDiv = document.createElement('div');
                            emptyDiv.style.padding = '20px';
                            emptyDiv.style.textAlign = 'center';
                            emptyDiv.style.color = 'rgba(255,255,255,0.5)';
                            emptyDiv.textContent = 'Aucune conversation';
                            chatListContainer.appendChild(emptyDiv);
                        }
                    } catch (error) {
                        console.error("Failed to load chats:", error);
                        showToast('Impossible de charger la liste des conversations', true);
                    }
                }

                async function loadChat(chatId) {
                    currentChatId = chatId;
                    chatWindow.innerHTML = '';
                    try {
                        const response = await fetch(`/api/chats/${chatId}`);
                        if (!response.ok) throw new Error('Failed to load chat');
                        const chatHistory = await response.json();
                        
                        for (const msg of chatHistory.messages) {
                            if (msg.role === 'user') {
                                const userMsgDiv = document.createElement('div');
                                userMsgDiv.className = 'message user-message';
                                userMsgDiv.textContent = msg.content;
                                chatWindow.appendChild(userMsgDiv);
                            } else if (msg.role === 'assistant') {
                                const turnDiv = document.createElement('div');
                                turnDiv.className = 'assistant-turn';
                                
                                const assistantMsgDiv = document.createElement('div');
                                assistantMsgDiv.className = 'message assistant-message';
                                assistantMsgDiv.style.position = 'relative';
                                
                                const renderedHtml = renderMarkdownWithHighlight(msg.content);
                                assistantMsgDiv.innerHTML = renderedHtml;
                                turnDiv.appendChild(assistantMsgDiv);
                                
                                try {
                                    addCopyButtonToMessage(assistantMsgDiv, msg.content);
                                } catch (err) {
                                    console.error('Error adding copy button:', err);
                                }
                                
                                if (msg.sources && msg.sources.length > 0) {
                                    const sourcesDiv = document.createElement('div');
                                    sourcesDiv.className = 'sources-container';
                                    sourcesDiv.innerHTML = `<strong>Sources :</strong><ul>${msg.sources.map(s => `<li>${escapeHtml(s)}</li>`).join('')}</ul>`;
                                    turnDiv.appendChild(sourcesDiv);
                                }
                                
                                chatWindow.appendChild(turnDiv);
                            }
                        }
                        
                        setTimeout(() => {
                            document.querySelectorAll('.assistant-message pre code').forEach((block) => {
                                try {
                                    hljs.highlightElement(block);
                                } catch (err) {
                                    console.error('Highlight error:', err);
                                }
                            });
                        }, 100);
                        
                        document.querySelectorAll('#chat-list-container .chat-list-item').forEach(li => {
                            if (li.dataset.chatId === chatId) {
                                li.classList.add('active');
                            } else {
                                li.classList.remove('active');
                            }
                        });
                        
                        updateBotMessageNav();
                        scrollToBottom();
                    } catch (error) {
                        console.error("Failed to load chat:", error);
                        showToast('Impossible de charger la conversation', true);
                        chatWindow.innerHTML = '<div class="empty-state">Erreur lors du chargement de la conversation. Veuillez réessayer.</div>';
                    }
                }

                function startNewChat() {
                    currentChatId = null;
                    chatWindow.innerHTML = '';
                    chunkQueue = [];
                    isProcessingQueue = false;
                    promptInput.value = '';
                    document.querySelectorAll('#chat-list-container .chat-list-item.active').forEach(li => li.classList.remove('active'));
                    botMessageElements = [];
                    currentBotMessageIndex = -1;
                    navControls.style.display = 'none';
                    const isReady = collectionSelect.value && modelSelect.value;
                    const welcomeMessage = isReady ? 
                        "✨ Nouvelle conversation ! Posez votre première question ci-dessous." : 
                        "Veuillez sélectionner une collection et un modèle pour commencer.";
                    chatWindow.innerHTML = `<div class="empty-state">${welcomeMessage}</div>`;
                    showToast('Nouvelle conversation créée');
                }
                
                function setupAvatar() {
                    if (avatarContainer) {
                        avatarContainer.onclick = () => avatarInput.click();
                    }
                    avatarInput.onchange = (event) => {
                        const file = event.target.files[0];
                        if (file && file.type.startsWith('image/')) {
                            const reader = new FileReader();
                            reader.onload = (e) => {
                                const dataUrl = e.target.result;
                                userAvatar.src = dataUrl;
                                localStorage.setItem('userAvatar', dataUrl);
                                showToast('Avatar mis à jour');
                            };
                            reader.readAsDataURL(file);
                        }
                    };
                    const savedAvatar = localStorage.getItem('userAvatar');
                    if (savedAvatar) {
                        userAvatar.src = savedAvatar;
                    }
                }

                function processChunkQueue(element) {
                    if (chunkQueue.length === 0) {
                        isProcessingQueue = false;
                        return;
                    }
                    isProcessingQueue = true;
                    const chunk = chunkQueue.shift();
                    const currentContent = element.getAttribute('data-raw') || '';
                    const newContent = currentContent + chunk;
                    element.setAttribute('data-raw', newContent);
                    element.innerHTML = renderMarkdownWithHighlight(newContent);
                    scrollToBottom();
                    requestAnimationFrame(() => processChunkQueue(element));
                }

                if (newChatBtn) {
                    const newBtn = newChatBtn.cloneNode(true);
                    newChatBtn.parentNode.replaceChild(newBtn, newChatBtn);
                    const freshNewChatBtn = document.getElementById('new-chat-btn');
                    freshNewChatBtn.addEventListener('click', (e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        startNewChat();
                    });
                }

                if (deleteAllChatsBtn) {
                    const deleteAllBtn = deleteAllChatsBtn.cloneNode(true);
                    deleteAllChatsBtn.parentNode.replaceChild(deleteAllBtn, deleteAllChatsBtn);
                    const freshDeleteAllBtn = document.getElementById('delete-all-chats-btn');
                    freshDeleteAllBtn.addEventListener('click', (e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        const hasChats = document.querySelectorAll('#chat-list-container .chat-list-item').length > 0;
                        if (!hasChats) {
                            showToast('Aucune conversation à supprimer', false, true);
                            return;
                        }
                        showCustomConfirm(null, null, true, () => {
                            startNewChat();
                        });
                    });
                }

                chatForm.addEventListener('submit', async (e) => {
                    e.preventDefault();
                    const prompt = promptInput.value.trim();
                    if (!prompt || sendBtn.disabled) return;

                    if (chatWindow.querySelector('.empty-state')) {
                        chatWindow.innerHTML = '';
                    }
                    
                    const userMsgDiv = document.createElement('div');
                    userMsgDiv.className = 'message user-message';
                    userMsgDiv.textContent = prompt;
                    chatWindow.appendChild(userMsgDiv);
                    
                    promptInput.value = '';
                    sendBtn.disabled = true;
                    scrollToBottom();

                    const assistantTurnDiv = document.createElement('div');
                    assistantTurnDiv.className = 'assistant-turn';
                    assistantTurnDiv.innerHTML = '<div class="spinner-container"><div class="spinner"><div></div><div></div><div></div></div></div>';
                    chatWindow.appendChild(assistantTurnDiv);
                    scrollToBottom();
                    
                    try {
                        const response = await fetch('/api/chat', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({
                                collection: collectionSelect.value,
                                model: modelSelect.value,
                                prompt: prompt,
                                chat_id: currentChatId,
                                temperature: parseFloat(temperatureSelect.value)
                            }),
                        });
                        if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);

                        const reader = response.body.getReader();
                        const decoder = new TextDecoder();
                        let buffer = '';
                        let sources = [];
                        let isFirstChunk = true;
                        let assistantMessageDiv = null;

                        while (true) {
                            const { done, value } = await reader.read();
                            if (done) break;

                            buffer += decoder.decode(value, { stream: true });
                            const lines = buffer.split('\\n');
                            buffer = lines.pop(); 

                            for (const line of lines) {
                                if (line.trim() === '') continue;
                                try {
                                    const data = JSON.parse(line);

                                    if (data.chat_id && !currentChatId) {
                                        currentChatId = data.chat_id;
                                        await loadChatsGrouped();
                                    }
                                    if (data.sources) sources = data.sources;
                                    
                                    if (isFirstChunk && data.chunk) {
                                        assistantTurnDiv.innerHTML = '';
                                        assistantMessageDiv = document.createElement('div');
                                        assistantMessageDiv.className = 'message assistant-message';
                                        assistantMessageDiv.setAttribute('data-raw', '');
                                        assistantTurnDiv.appendChild(assistantMessageDiv);
                                        isFirstChunk = false;
                                    }

                                    if (data.chunk) {
                                        chunkQueue.push(data.chunk);
                                        if (!isProcessingQueue && assistantMessageDiv) {
                                            processChunkQueue(assistantMessageDiv);
                                        }
                                    }
                                    if (data.error) {
                                        if (assistantMessageDiv) {
                                            assistantMessageDiv.innerHTML = `<p>❌ Erreur : ${escapeHtml(data.error)}</p>`;
                                        } else {
                                            assistantTurnDiv.innerHTML = '';
                                            const errorDiv = document.createElement('div');
                                            errorDiv.className = 'message assistant-message';
                                            errorDiv.innerHTML = `<p>❌ Erreur : ${escapeHtml(data.error)}</p>`;
                                            assistantTurnDiv.appendChild(errorDiv);
                                        }
                                        showToast('Erreur lors de la réponse', true);
                                    }
                                } catch (e) {
                                    console.error("Error parsing JSON:", e, line);
                                }
                            }
                        }
                        
                        await new Promise(resolve => {
                            const check = () => {
                                if (!isProcessingQueue) {
                                    resolve();
                                } else {
                                    setTimeout(check, 50);
                                }
                            };
                            check();
                        });
                        
                        if (assistantMessageDiv) {
                            const finalContent = assistantMessageDiv.getAttribute('data-raw') || '';
                            if (finalContent) {
                                const existingBtn = assistantMessageDiv.querySelector('.copy-button');
                                if (existingBtn) existingBtn.remove();
                                addCopyButtonToMessage(assistantMessageDiv, finalContent);
                            }
                        }
                        
                        if (sources.length > 0 && assistantTurnDiv) {
                             const sourcesDiv = document.createElement('div');
                             sourcesDiv.className = 'sources-container';
                             sourcesDiv.innerHTML = `<strong>Sources :</strong><ul>${sources.map(s => `<li>${escapeHtml(s)}</li>`).join('')}</ul>`;
                             assistantTurnDiv.appendChild(sourcesDiv);
                        }

                    } catch (error) {
                        console.error("Streaming failed:", error);
                        assistantTurnDiv.innerHTML = '';
                        const errorDiv = document.createElement('div');
                        errorDiv.className = 'message assistant-message';
                        errorDiv.innerHTML = "<p>❌ Désolé, une erreur s'est produite. Veuillez réessayer.</p>";
                        assistantTurnDiv.appendChild(errorDiv);
                        showToast('Échec de la réponse', true);
                    } finally {
                        sendBtn.disabled = false;
                        await loadChatsGrouped();
                        updateBotMessageNav();
                        scrollToBottom();
                    }
                });
                
                async function initializeApp() {
                    await fetchAndPopulate('/api/collections', collectionSelect, 'Sélectionner une collection', 'Aucune collection trouvée');
                    await fetchAndPopulate('/api/models', modelSelect, 'Sélectionner un modèle', 'Aucun modèle trouvé');
                    
                    try {
                        const configRes = await fetch('/api/config');
                        const config = await configRes.json();
                        
                        if (config.default_model) {
                            const modelExists = Array.from(modelSelect.options).some(opt => opt.value === config.default_model);
                            if (!modelExists) {
                                modelSelect.add(new Option(config.default_model, config.default_model));
                            }
                            modelSelect.value = config.default_model;
                        }
                    } catch (e) {
                        console.error("Impossible de charger la config serveur:", e);
                    }

                    loadChatsGrouped();
                    checkSelections();
                    setupAvatar();
                }
                
                initializeApp();
                
                collectionSelect.addEventListener('change', checkSelections);
                modelSelect.addEventListener('change', checkSelections);
                if (navUpBtn) navUpBtn.addEventListener('click', () => navigateBotMessages(-1));
                if (navDownBtn) navDownBtn.addEventListener('click', () => navigateBotMessages(1));
            });
        </script>
    </body>
    </html>
    """

    # Injection dynamique du chemin de base si l'application est montée (ex: /rag)
    if root_path:
        html_content = html_content.replace('href="/', f'href="{root_path}/')
        html_content = html_content.replace('src="/', f'src="{root_path}/')
        html_content = html_content.replace("url('/", f"url('{root_path}/")
        html_content = html_content.replace("fetch('/", f"fetch('{root_path}/")
        html_content = html_content.replace("fetch(`/api", f"fetch(`{root_path}/api")
        html_content = html_content.replace("fetchAndPopulate('/", f"fetchAndPopulate('{root_path}/")
        
    return html_content

def run_server():
    import argparse
    import uvicorn
    
    parser = argparse.ArgumentParser(description="Démarrer l'assistant RAG Chat")
    parser.add_argument("--host", type=str, default="0.0.0.0", help="L'adresse hôte (défaut: 0.0.0.0)")
    parser.add_argument("--port", type=int, default=8000, help="Le port du serveur (défaut: 8000)")
    parser.add_argument("--model", type=str, default="", help="Le modèle LLM par défaut (ex: llama3)")
    
    args = parser.parse_args()
    
    os.environ["RAG_DEFAULT_MODEL"] = args.model
    
    print(f"🌍 Démarrage du serveur RAG sur http://{args.host}:{args.port}")
    if args.model:
        print(f"🤖 Modèle par défaut configuré sur : '{args.model}'")
        
    uvicorn.run(app, host=args.host, port=args.port)

if __name__ == "__main__":
    run_server()