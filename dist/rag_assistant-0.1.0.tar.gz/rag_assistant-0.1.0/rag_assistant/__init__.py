# Contenu de rag_assistant/__init__.py
from .rag_vectorizer_gui import DocumentProcessor, CollectionManager, run_gui
from .rag_chat_app import run_server, build_conversation_messages, stream_ollama_chat, app

__version__ = "0.1.0"